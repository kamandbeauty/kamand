package com.modir.forushgah.presentation.common

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.modir.forushgah.domain.model.Product
import com.modir.forushgah.presentation.products.ProductListViewModel

/**
 * Reusable product search + pick UI (spec §10). Intended to be opened as a
 * full-screen route or a bottom sheet from the future Order screen (Phase 3);
 * NOT wired into navigation yet since no order screen consumes it in Phase 2,
 * but built now so Phase 3 can drop it in directly.
 */
@Composable
fun ProductSelectorRoute(
    onProductSelected: (Product) -> Unit,
    onBack: () -> Unit,
    viewModel: ProductListViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsState()
    ProductSelector(
        products = state.products,
        query = state.query,
        onQueryChange = viewModel::onQueryChange,
        onProductSelected = onProductSelected,
        onBack = onBack,
    )
}

@Composable
fun ProductSelector(
    products: List<Product>,
    query: String,
    onQueryChange: (String) -> Unit,
    onProductSelected: (Product) -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("انتخاب محصول") },
                navigationIcon = { TextButton(onClick = onBack) { Text("بازگشت") } },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            SearchField(query = query, onQueryChange = onQueryChange, placeholder = "جستجوی محصول یا بارکد")

            if (products.isEmpty()) {
                Text(
                    "محصولی یافت نشد",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                LazyColumn {
                    items(products, key = { it.id }) { product ->
                        ProductRow(
                            product = product,
                            onClick = { onProductSelected(product) },
                            trailingContent = {
                                Text(product.sellingPrice.toPersianDisplayString(), style = MaterialTheme.typography.titleMedium)
                            },
                        )
                    }
                }
            }
        }
    }
}
