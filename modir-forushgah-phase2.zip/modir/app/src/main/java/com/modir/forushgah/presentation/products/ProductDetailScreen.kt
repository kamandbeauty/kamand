package com.modir.forushgah.presentation.products

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.modir.forushgah.core.common.PersianNumberFormatter
import com.modir.forushgah.core.designsystem.component.StockBadge
import com.modir.forushgah.core.designsystem.component.stockLevelOf
import com.modir.forushgah.domain.model.InventoryMovement
import com.modir.forushgah.domain.model.InventoryMovementType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProductDetailRoute(
    onBack: () -> Unit,
    onEdit: (Long) -> Unit,
    onAdjustStock: (Long) -> Unit,
    viewModel: ProductDetailViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsState()
    ProductDetailScreen(state = state, onBack = onBack, onEdit = onEdit, onAdjustStock = onAdjustStock)
}

@Composable
fun ProductDetailScreen(
    state: ProductDetailUiState,
    onBack: () -> Unit,
    onEdit: (Long) -> Unit,
    onAdjustStock: (Long) -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.product?.name ?: "جزئیات محصول") },
                navigationIcon = { TextButton(onClick = onBack) { Text("بازگشت") } },
                actions = {
                    state.product?.let { p -> TextButton(onClick = { onEdit(p.id) }) { Text("ویرایش") } }
                },
            )
        },
    ) { padding ->
        val product = state.product
        if (state.isLoading || product == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(modifier = Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "موجودی فعلی: ${product.stockQuantity}", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.width(8.dp))
                            StockBadge(level = stockLevelOf(product.stockQuantity, product.minimumStock), alwaysShow = true)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        InfoRow("قیمت فروش", product.sellingPrice.toPersianDisplayString())
                        InfoRow("قیمت خرید", product.purchasePrice.toPersianDisplayString())
                        InfoRow("سود تخمینی هر واحد", product.estimatedProfitPerUnit.toPersianDisplayString())
                        InfoRow("حداقل موجودی هشدار", PersianNumberFormatter.toPersianDigits(product.minimumStock.toString()))
                        InfoRow("کد محصول", product.sku)
                    }
                }
            }
            item {
                TextButton(onClick = { onAdjustStock(product.id) }) { Text("تنظیم دستی موجودی") }
            }
            item {
                Text("گردش کالا", style = MaterialTheme.typography.titleLarge)
            }
            if (state.movements.isEmpty()) {
                item {
                    Text(
                        "گردش کالایی ثبت نشده",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                items(state.movements, key = { it.id }) { movement ->
                    MovementRow(movement)
                    Divider()
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Medium)
    }
}

private val dateFormatter = SimpleDateFormat("d MMMM", Locale("fa"))

@Composable
private fun MovementRow(movement: InventoryMovement) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text(text = movementTypeLabel(movement.movementType), style = MaterialTheme.typography.bodyLarge)
            Text(
                text = "${movement.stockBefore} → ${movement.stockAfter}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            val deltaText = if (movement.quantityDelta >= 0) "+${movement.quantityDelta}" else "${movement.quantityDelta}"
            Text(text = deltaText, style = MaterialTheme.typography.titleMedium)
            Text(
                text = dateFormatter.format(Date(movement.createdAt)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private fun movementTypeLabel(type: InventoryMovementType): String = when (type) {
    InventoryMovementType.PURCHASE -> "ورود کالا (خرید)"
    InventoryMovementType.SALE -> "فروش"
    InventoryMovementType.RETURN -> "مرجوعی"
    InventoryMovementType.ADJUSTMENT_IN -> "تنظیم دستی (افزایش)"
    InventoryMovementType.ADJUSTMENT_OUT -> "تنظیم دستی (کاهش)"
    InventoryMovementType.DAMAGED -> "آسیب‌دیده"
    InventoryMovementType.OTHER -> "سایر"
}
