package com.modir.forushgah.presentation.products

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.modir.forushgah.data.repository.InventoryRepository
import com.modir.forushgah.data.repository.ProductRepository
import com.modir.forushgah.domain.model.InventoryReferenceType
import com.modir.forushgah.domain.model.Product
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class StockAdjustmentUiState(
    val product: Product? = null,
    val newStockInput: String = "",
    val reason: String = "",
    val isSaving: Boolean = false,
    val isSaved: Boolean = false,
    val error: String? = null,
) {
    /** Live-computed delta preview, per spec §4 ("system calculates the difference automatically"). */
    val delta: Int?
        get() {
            val current = product?.stockQuantity ?: return null
            val new = newStockInput.toIntOrNull() ?: return null
            return new - current
        }
}

@HiltViewModel
class StockAdjustmentViewModel @Inject constructor(
    private val productRepository: ProductRepository,
    private val inventoryRepository: InventoryRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val productId: Long = checkNotNull(savedStateHandle["productId"])
    private val _state = MutableStateFlow(StockAdjustmentUiState())
    val state: StateFlow<StockAdjustmentUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            productRepository.getById(productId)?.let { product ->
                _state.update { it.copy(product = product, newStockInput = product.stockQuantity.toString()) }
            }
        }
    }

    fun onNewStockChange(value: String) = _state.update { it.copy(newStockInput = value.filter { c -> c.isDigit() }) }
    fun onReasonChange(value: String) = _state.update { it.copy(reason = value) }

    fun save() {
        val s = _state.value
        val newStock = s.newStockInput.toIntOrNull()
        if (newStock == null || newStock < 0) {
            _state.update { it.copy(error = "موجودی جدید باید عددی معتبر و غیرمنفی باشد") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(isSaving = true, error = null) }
            inventoryRepository.adjustStockTo(
                productId = productId,
                newStock = newStock,
                reason = s.reason.ifBlank { null },
            )
            _state.update { it.copy(isSaving = false, isSaved = true) }
        }
    }
}
