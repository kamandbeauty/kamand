package com.modir.forushgah.presentation.customers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.modir.forushgah.domain.model.CustomerProfile
import com.modir.forushgah.presentation.common.InitialsAvatar

@Composable
fun CustomerDetailRoute(
    onBack: () -> Unit,
    onEdit: (Long) -> Unit,
    viewModel: CustomerDetailViewModel = hiltViewModel(),
) {
    val profile by viewModel.profile.collectAsState()
    CustomerDetailScreen(profile = profile, onBack = onBack, onEdit = onEdit)
}

@Composable
fun CustomerDetailScreen(
    profile: CustomerProfile?,
    onBack: () -> Unit,
    onEdit: (Long) -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(profile?.customer?.name ?: "جزئیات مشتری") },
                navigationIcon = { TextButton(onClick = onBack) { Text("بازگشت") } },
                actions = { profile?.let { TextButton(onClick = { onEdit(it.customer.id) }) { Text("ویرایش") } } },
            )
        },
    ) { padding ->
        if (profile == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(modifier = Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                InitialsAvatar(name = profile.customer.name)
                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text(profile.customer.name, style = MaterialTheme.typography.titleLarge)
                    profile.customer.mobile?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }

            profile.customer.address?.let { StatLine("آدرس", it) }
            profile.customer.city?.let { StatLine("شهر", it) }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("خلاصه مالی", style = MaterialTheme.typography.titleMedium)
                    StatLine("تعداد سفارش‌ها", profile.totalOrders.toString())
                    StatLine("مجموع خرید", profile.totalPurchases.toPersianDisplayString())
                    StatLine("سود ایجادشده", profile.totalProfit.toPersianDisplayString())
                    StatLine("مطالبات باقی‌مانده", profile.outstandingReceivable.toPersianDisplayString())
                    Text(
                        "مبالغ مالی تا تکمیل موتور مالی (فاز ۴) صفر نمایش داده می‌شوند",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value)
    }
}
