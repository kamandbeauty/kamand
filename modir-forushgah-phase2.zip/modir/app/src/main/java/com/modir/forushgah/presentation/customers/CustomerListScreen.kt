package com.modir.forushgah.presentation.customers

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Divider
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.modir.forushgah.core.designsystem.component.EmptyState
import com.modir.forushgah.presentation.common.CustomerRow
import com.modir.forushgah.presentation.common.SearchField

@Composable
fun CustomerListRoute(
    onCustomerClick: (Long) -> Unit,
    onAddCustomer: () -> Unit,
    onBack: () -> Unit,
    viewModel: CustomerListViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsState()
    CustomerListScreen(
        state = state,
        onQueryChange = viewModel::onQueryChange,
        onCustomerClick = onCustomerClick,
        onAddCustomer = onAddCustomer,
        onBack = onBack,
    )
}

@Composable
fun CustomerListScreen(
    state: CustomerListUiState,
    onQueryChange: (String) -> Unit,
    onCustomerClick: (Long) -> Unit,
    onAddCustomer: () -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مشتریان") },
                navigationIcon = { TextButton(onClick = onBack) { Text("بازگشت") } },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddCustomer) {
                Icon(Icons.Filled.Add, contentDescription = "افزودن مشتری")
            }
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (state.isEmpty) {
                EmptyState(
                    title = "هنوز مشتری‌ای ثبت نشده",
                    subtitle = "با افزودن اولین مشتری، اطلاعاتش را اینجا مدیریت کنید",
                    ctaLabel = "افزودن مشتری",
                    onCtaClick = onAddCustomer,
                    modifier = Modifier.align(Alignment.Center),
                )
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    SearchField(query = state.query, onQueryChange = onQueryChange, placeholder = "جستجوی مشتری یا شماره تماس")
                    LazyColumn {
                        items(state.customers, key = { it.id }) { customer ->
                            CustomerRow(customer = customer, onClick = { onCustomerClick(customer.id) })
                            Divider()
                        }
                    }
                }
            }
        }
    }
}
