package com.modir.forushgah.presentation.products

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun StockAdjustmentRoute(
    onSaved: () -> Unit,
    onBack: () -> Unit,
    viewModel: StockAdjustmentViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state.isSaved) {
        if (state.isSaved) onSaved()
    }

    StockAdjustmentScreen(
        state = state,
        onBack = onBack,
        onNewStockChange = viewModel::onNewStockChange,
        onReasonChange = viewModel::onReasonChange,
        onSave = viewModel::save,
    )
}

@Composable
fun StockAdjustmentScreen(
    state: StockAdjustmentUiState,
    onBack: () -> Unit,
    onNewStockChange: (String) -> Unit,
    onReasonChange: (String) -> Unit,
    onSave: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تنظیم دستی موجودی") },
                navigationIcon = { TextButton(onClick = onBack) { Text("بازگشت") } },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            state.product?.let { product ->
                Text(product.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    "موجودی فعلی: ${product.stockQuantity}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            OutlinedTextField(
                value = state.newStockInput,
                onValueChange = onNewStockChange,
                label = { Text("موجودی جدید") },
                modifier = Modifier.fillMaxWidth(),
            )

            state.delta?.let { delta ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("تغییر محاسبه‌شده", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = if (delta >= 0) "+$delta" else "$delta",
                            style = MaterialTheme.typography.headlineSmall,
                        )
                    }
                }
            }

            OutlinedTextField(
                value = state.reason,
                onValueChange = onReasonChange,
                label = { Text("دلیل تغییر (اختیاری)") },
                modifier = Modifier.fillMaxWidth(),
            )

            state.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Button(onClick = onSave, modifier = Modifier.fillMaxWidth(), enabled = !state.isSaving) {
                Text("ثبت تغییر موجودی")
            }
        }
    }
}
