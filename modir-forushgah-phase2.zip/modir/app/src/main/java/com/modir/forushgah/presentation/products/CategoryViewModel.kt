package com.modir.forushgah.presentation.products

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.modir.forushgah.data.repository.CategoryRepository
import com.modir.forushgah.domain.model.Category
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CategoryScreenState(
    val categories: List<Category> = emptyList(),
    val newCategoryName: String = "",
)

@HiltViewModel
class CategoryViewModel @Inject constructor(
    private val categoryRepository: CategoryRepository,
) : ViewModel() {

    private val newCategoryName = MutableStateFlow("")

    val state: StateFlow<CategoryScreenState> = combine(
        categoryRepository.observeAll(), newCategoryName,
    ) { categories, name -> CategoryScreenState(categories = categories, newCategoryName = name) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CategoryScreenState())

    fun onNewCategoryNameChange(value: String) { newCategoryName.value = value }

    fun addCategory() {
        val name = newCategoryName.value.trim()
        if (name.isBlank()) return
        viewModelScope.launch {
            categoryRepository.create(name)
            newCategoryName.value = ""
        }
    }

    fun archiveCategory(categoryId: Long) {
        viewModelScope.launch { categoryRepository.archive(categoryId) }
    }
}
