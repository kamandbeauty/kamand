<?php
/**
 * wp-admin panel: 6 sub-pages sharing one visual language.
 *
 * The native dark WP sidebar is left untouched; only the content column is
 * restyled: white stat cards with soft round colour icons + green growth
 * badges, a clean approval table with a green "verify" pill, blue range
 * sliders for the formula weights, and a dark live console with mac-style
 * traffic lights and monospace [HH:MM:SS] log lines.
 *
 * @package Havato
 */

defined( 'ABSPATH' ) || exit;

/**
 * Admin UI controller.
 */
class Havato_Admin {

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_havato_admin_action', array( __CLASS__, 'handle_post' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
	}

	/**
	 * Register the menu and its 6 sub-pages.
	 */
	public static function menu() {
		$cap = 'manage_options';

		add_menu_page(
			'Havato',
			'Havato — هواتو',
			$cap,
			'havato',
			array( __CLASS__, 'page_dashboard' ),
			'dashicons-coffee',
			26
		);

		$pages = array(
			'havato'            => array( 'admin_dashboard', 'page_dashboard' ),
			'havato-approvals'  => array( 'admin_approvals', 'page_approvals' ),
			'havato-events'     => array( 'admin_events', 'page_events' ),
			'havato-chats'      => array( 'admin_chats', 'page_chats' ),
			'havato-venues'     => array( 'admin_venues', 'page_venues' ),
			'havato-import'     => array( 'admin_import', 'page_import' ),
			'havato-matcher'    => array( 'admin_matcher', 'page_matcher' ),
			'havato-weights'    => array( 'admin_weights', 'page_weights' ),
			'havato-google'     => array( 'admin_google', 'page_google' ),
			'havato-theme'      => array( 'admin_theme', 'page_theme' ),
			'havato-locale'     => array( 'admin_locale', 'page_locale' ),
		);

		foreach ( $pages as $slug => $conf ) {
			add_submenu_page(
				'havato',
				Havato_I18N::t( $conf[0] ),
				Havato_I18N::t( $conf[0] ),
				$cap,
				$slug,
				array( __CLASS__, $conf[1] )
			);
		}
	}

	/**
	 * Load the admin CSS/JS only on Havato screens.
	 *
	 * @param string $hook Current screen hook.
	 */
	public static function assets( $hook ) {
		$is_havato = ( false !== strpos( $hook, 'havato' ) );

		// The users.php badges need a sliver of CSS too.
		if ( ! $is_havato && 'users.php' !== $hook ) {
			return;
		}

		wp_enqueue_style( 'havato-admin', HAVATO_URL . 'assets/css/havato-admin.css', array(), HAVATO_VERSION );

		if ( ! $is_havato ) {
			return;
		}

		wp_enqueue_script( 'havato-admin', HAVATO_URL . 'assets/js/havato-admin.js', array(), HAVATO_VERSION, true );

		wp_localize_script(
			'havato-admin',
			'HAVATO_ADMIN',
			array(
				'rest'  => esc_url_raw( rest_url( Havato_REST::NS ) ),
				'nonce' => wp_create_nonce( 'wp_rest' ),
				'lang'  => Havato_I18N::current_lang(),
				'i18n'  => Havato_I18N::flat( Havato_I18N::current_lang() ),
			)
		);
	}

	/**
	 * Flash messages after a POST redirect.
	 */
	public static function notices() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['havato_msg'] ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$msg = sanitize_text_field( wp_unslash( $_GET['havato_msg'] ) );
		printf( '<div class="notice notice-success is-dismissible"><p>%s</p></div>', esc_html( $msg ) );
	}

	/* =====================================================================
	 * Shared chrome
	 * ================================================================== */

	/**
	 * Page header + tab strip.
	 *
	 * @param string $title    Page title.
	 * @param string $subtitle Sub title.
	 */
	private static function head( $title, $subtitle = '' ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$current = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'havato';

		$tabs = array(
			'havato'           => Havato_I18N::t( 'admin_dashboard' ),
			'havato-approvals' => Havato_I18N::t( 'admin_approvals' ),
			'havato-events'    => Havato_I18N::t( 'admin_events' ),
			'havato-chats'     => Havato_I18N::t( 'admin_chats' ),
			'havato-venues'    => Havato_I18N::t( 'admin_venues' ),
			'havato-import'    => Havato_I18N::t( 'admin_import' ),
			'havato-matcher'   => Havato_I18N::t( 'admin_matcher' ),
			'havato-weights'   => Havato_I18N::t( 'admin_weights' ),
			'havato-google'    => Havato_I18N::t( 'admin_google' ),
			'havato-theme'     => Havato_I18N::t( 'admin_theme' ),
			'havato-locale'    => Havato_I18N::t( 'admin_locale' ),
		);

		echo '<div class="wrap hv-admin">';
		echo '<div class="hv-admin-head">';
		echo '<div class="hv-admin-brand"><span class="hv-admin-logo">H</span><div>';
		echo '<h1>' . esc_html( $title ) . '</h1>';
		if ( $subtitle ) {
			echo '<p>' . esc_html( $subtitle ) . '</p>';
		}
		echo '</div></div>';
		echo '</div>';

		echo '<nav class="hv-admin-tabs">';
		foreach ( $tabs as $slug => $label ) {
			printf(
				'<a class="hv-admin-tab%s" href="%s">%s</a>',
				$slug === $current ? ' is-active' : '',
				esc_url( admin_url( 'admin.php?page=' . $slug ) ),
				esc_html( $label )
			);
		}
		echo '</nav>';
	}

	/**
	 * Close the wrapper.
	 */
	private static function foot() {
		echo '</div>';
	}

	/**
	 * One stat card.
	 *
	 * @param string $label  Label.
	 * @param string $value  Big number.
	 * @param string $color  blue|green|orange|pink.
	 * @param string $icon   Dashicon suffix.
	 * @param string $growth Growth badge text (optional).
	 */
	private static function stat_card( $label, $value, $color, $icon, $growth = '' ) {
		Havato_Admin_UI::stat_card( $label, $value, $color, $icon, $growth );
	}

	/**
	 * The dark live console.
	 *
	 * @param int    $limit How many lines.
	 * @param string $title Card title.
	 */
	private static function console( $limit = 18, $title = '' ) {
		$lines = Havato_Logger::tail( $limit );

		echo '<div class="hv-adm-console" id="hv-console">';
		echo '<div class="hv-adm-console-bar"><i class="is-red"></i><i class="is-yellow"></i><i class="is-green"></i>';
		echo '<span>' . esc_html( $title ? $title : Havato_I18N::t( 'live_console' ) ) . '</span></div>';
		echo '<div class="hv-adm-console-body" id="hv-console-body">';

		if ( empty( $lines ) ) {
			echo '<p class="hv-line is-info">[--:--:--] Havato matcher engine idle — waiting for events…</p>';
		} else {
			foreach ( $lines as $line ) {
				printf(
					'<p class="hv-line is-%s">[%s] %s</p>',
					esc_attr( $line['level'] ),
					esc_html( $line['time'] ),
					esc_html( $line['msg'] )
				);
			}
		}

		echo '</div></div>';
	}

	/**
	 * Hidden nonce + action fields for the admin-post form handler.
	 *
	 * @param string $action Sub-action name.
	 */
	private static function form_fields( $action ) {
		wp_nonce_field( 'havato_admin', 'havato_nonce' );
		echo '<input type="hidden" name="action" value="havato_admin_action">';
		echo '<input type="hidden" name="havato_action" value="' . esc_attr( $action ) . '">';

		// Remember where we came from so the redirect can come back here.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$current = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		echo '<input type="hidden" name="return_page" value="' . esc_attr( $current ) . '">';
	}

	/**
	 * A labelled blue range slider.
	 *
	 * @param string $name  Field name.
	 * @param string $label Label.
	 * @param mixed  $value Current value.
	 * @param int    $min   Min.
	 * @param int    $max   Max.
	 * @param string $unit  Unit suffix.
	 */
	private static function slider( $name, $label, $value, $min = 0, $max = 100, $unit = '' ) {
		printf(
			'<div class="hv-adm-slider">
				<div class="hv-adm-slider-top"><span>%1$s</span><b data-out="%2$s">%3$s%4$s</b></div>
				<input type="range" class="hv-adm-range" name="%2$s" value="%5$s" min="%6$d" max="%7$d" step="1" data-unit="%4$s">
			</div>',
			esc_html( $label ),
			esc_attr( $name ),
			esc_html( $value ),
			esc_attr( $unit ),
			esc_attr( $value ),
			(int) $min,
			(int) $max
		);
	}

	/* =====================================================================
	 * Page 1 — statistics dashboard
	 * ================================================================== */

	/**
	 * Dashboard page.
	 */
	public static function page_dashboard() {
		Havato_DB::ensure_tables();
		$stats = Havato_REST::stats_payload();
		$lang  = Havato_I18N::current_lang();

		$fmt = function ( $n ) use ( $lang ) {
			return 'fa' === $lang ? Havato_Jalali::fa_digits( number_format( (int) $n ) ) : number_format( (int) $n );
		};

		$growth = ( $stats['growth'] >= 0 ? '+' : '' ) . $stats['growth'] . '%';
		if ( 'fa' === $lang ) {
			$growth = Havato_Jalali::fa_digits( $growth );
		}

		self::head( Havato_I18N::t( 'admin_dashboard' ), Havato_I18N::t( 'tagline' ) );

		echo '<div class="hv-adm-stats">';
		self::stat_card( Havato_I18N::t( 'stat_active_users' ), $fmt( $stats['active_users'] ), 'blue', 'groups', $growth );
		self::stat_card( Havato_I18N::t( 'stat_matched_tables' ), $fmt( $stats['matched_tables'] ), 'green', 'yes-alt' );
		self::stat_card( Havato_I18N::t( 'stat_venues' ), $fmt( $stats['venues'] ), 'orange', 'store' );
		self::stat_card( Havato_I18N::t( 'stat_signups' ), $fmt( $stats['signups'] ), 'pink', 'tickets-alt' );
		echo '</div>';

		echo '<div class="hv-adm-grid">';

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'admin_approvals' ) ) . '</h2>';
		self::render_pending_table( 5 );
		echo '<p><a class="hv-adm-btn hv-adm-btn-ghost" href="' . esc_url( admin_url( 'admin.php?page=havato-approvals' ) ) . '">' .
			esc_html( Havato_I18N::t( 'admin_approvals' ) ) . '</a></p>';
		echo '</div>';

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'live_console' ) ) . '</h2>';
		self::console( 10 );
		echo '</div>';

		echo '</div>';

		self::render_demo_card();

		self::foot();
	}

	/**
	 * Demo content: create the sample directory, or remove it again.
	 *
	 * The removal only ever touches rows flagged is_demo, so real cafés are
	 * safe even when they sit in the same city as the samples.
	 */
	private static function render_demo_card() {
		require_once HAVATO_PATH . 'includes/class-havato-seeder.php';

		$stats = Havato_Seeder::stats();
		$has   = ( $stats['venues'] > 0 || $stats['events'] > 0 );

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'demo_title' ) ) . '</h2>';

		if ( $has ) {
			printf(
				'<p><span class="hv-adm-badge is-blue">%s</span></p>',
				esc_html( sprintf( Havato_I18N::t( 'demo_present' ), $stats['venues'], $stats['events'] ) )
			);
		}

		echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'demo_hint' ) ) . '</p>';

		echo '<div class="hv-adm-actions">';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		self::form_fields( 'seed' );
		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-blue">' .
			esc_html( Havato_I18N::t( 'demo_create' ) ) . '</button>';
		echo '</form>';

		if ( $has ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" ' .
				'onsubmit="return confirm(' . esc_attr( wp_json_encode( Havato_I18N::t( 'demo_confirm' ) ) ) . ');">';
			self::form_fields( 'purge_demo' );
			echo '<button type="submit" class="hv-adm-btn hv-adm-btn-danger">' .
				esc_html( Havato_I18N::t( 'demo_remove' ) ) . '</button>';
			echo '</form>';
		}

		echo '</div></div>';
	}

	/* =====================================================================
	 * Page 2 — approvals (venues + menus + photo reports)
	 * ================================================================== */

	/**
	 * Approvals page.
	 */
	public static function page_approvals() {
		Havato_DB::ensure_tables();
		self::head( Havato_I18N::t( 'admin_approvals' ), Havato_I18N::t( 'verify_action' ) );

		self::render_new_venue_form();

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'stat_venues' ) ) . '</h2>';
		self::render_pending_table( 50 );
		echo '</div>';

		self::render_menu_queue();
		self::render_event_requests();
		self::render_photo_reports();

		self::foot();
	}

	/**
	 * Every guest suggestion on the platform, across all cafés.
	 *
	 * The café sees its own on its dashboard. The administrator sees all of
	 * them, which is the only place the pattern shows: a café that keeps
	 * receiving requests and never turns one into a gathering is worth a
	 * phone call.
	 */
	private static function render_event_requests() {
		global $wpdb;

		$requests = Havato_DB::table( 'event_requests' );
		$venues   = Havato_DB::table( 'venues' );
		$lang     = Havato_I18N::current_lang();

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$only_pending = ! isset( $_GET['requests'] ) || 'all' !== $_GET['requests'];

		$where = $only_pending ? "WHERE q.status = 'pending'" : '';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$pending_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $requests WHERE status = 'pending'" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			"SELECT q.*, v.name AS venue_name, v.city AS venue_city
			 FROM $requests q
			 LEFT JOIN $venues v ON v.id = q.venue_id
			 $where
			 ORDER BY FIELD(q.status,'pending','accepted','declined'), q.preferred_date ASC
			 LIMIT 100",
			ARRAY_A
		);

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'guest_requests' ) ) . '</h2>';
		echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'admin_requests_hint' ) ) . '</p>';

		printf(
			'<p><a class="hv-adm-btn hv-adm-btn-ghost" href="%s">%s</a> ' .
			'<span class="hv-adm-badge is-yellow">%s %s</span></p>',
			esc_url(
				add_query_arg(
					array( 'page' => 'havato-approvals', 'requests' => $only_pending ? 'all' : 'pending' ),
					admin_url( 'admin.php' )
				)
			),
			esc_html( Havato_I18N::t( $only_pending ? 'show_all' : 'show_pending' ) ),
			esc_html( number_format_i18n( $pending_total ) ),
			esc_html( Havato_I18N::t( 'request_pending' ) )
		);

		if ( empty( $rows ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p></div>';
			return;
		}

		echo '<table class="hv-adm-table"><thead><tr>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_date' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'venue_name' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'event_subject' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_manager' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_status' ) ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rows as $row ) {
			$badge = 'pending' === $row['status'] ? 'is-yellow'
				: ( 'accepted' === $row['status'] ? 'is-green' : 'is-gray' );
			$city  = havato_city_label( (string) $row['venue_city'] );

			echo '<tr>';
			echo '<td><strong>' . esc_html( Havato_Jalali::format( $row['preferred_date'], $lang ) ) . '</strong><br>' .
				'<span class="hv-adm-muted">' . esc_html( substr( (string) $row['preferred_time'], 0, 5 ) ) . '</span></td>';

			echo '<td>' . esc_html( $row['venue_name'] );
			if ( ! empty( $city[ $lang ] ) ) {
				echo '<br><span class="hv-adm-muted">' . esc_html( $city[ $lang ] ) . '</span>';
			}
			echo '</td>';

			echo '<td>' . esc_html( $row['subject'] );
			if ( ! empty( $row['note'] ) ) {
				echo '<br><span class="hv-adm-muted">' . esc_html( $row['note'] ) . '</span>';
			}
			echo '</td>';

			echo '<td>' . esc_html( havato_display_name( (int) $row['user_id'] ) ) . '</td>';
			echo '<td><span class="hv-adm-badge ' . esc_attr( $badge ) . '">' .
				esc_html( Havato_I18N::t( 'request_' . $row['status'] ) ) . '</span></td>';
			echo '</tr>';
		}

		echo '</tbody></table></div>';
	}

	/* =====================================================================
	 * Page — all events & their registered guests
	 * ================================================================== */

	/**
	 * Every event on the platform, with the people signed up to each one.
	 *
	 * Read-only overview: the admin can see who registered, whether they paid
	 * and whether the café checked them in, without leaving the page.
	 */
	public static function page_events() {
		global $wpdb;
		Havato_DB::ensure_tables();

		$lang   = Havato_I18N::current_lang();
		$events = Havato_DB::table( 'events' );
		$venues = Havato_DB::table( 'venues' );
		$regs   = Havato_DB::table( 'event_registrations' );

		// A single event was asked for: show its own screen instead of the list.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$single = isset( $_GET['event'] ) ? sanitize_text_field( wp_unslash( $_GET['event'] ) ) : '';
		if ( '' !== $single ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			self::page_event_single( $single, isset( $_GET['edit'] ) );
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$paged = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;

		$per_page = 20;
		$offset   = ( $paged - 1 ) * $per_page;

		$where = '1=1';
		if ( in_array( $status, array( 'open', 'matched', 'completed', 'cancelled', 'pending_admin' ), true ) ) {
			$where .= $wpdb->prepare( ' AND e.status = %s', $status );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $events e WHERE $where" );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT e.*, v.name AS venue_name, v.city AS venue_city,
						(SELECT COALESCE(SUM(r.seats),0) FROM $regs r WHERE r.event_id = e.id
						 AND r.status <> 'cancelled') AS taken
				 FROM $events e
				 LEFT JOIN $venues v ON v.id = e.venue_id
				 WHERE $where
				 ORDER BY e.event_date DESC, e.event_time DESC
				 LIMIT %d OFFSET %d",
				$per_page,
				$offset
			),
			ARRAY_A
		);

		self::head( Havato_I18N::t( 'admin_events' ), Havato_I18N::t( 'explore_title' ) );

		// Status filter.
		$filters = array(
			''              => Havato_I18N::t( 'filter' ),
			'open'          => Havato_I18N::t( 'status_open' ),
			'matched'       => Havato_I18N::t( 'status_matched' ),
			'completed'     => Havato_I18N::t( 'status_completed' ),
			'cancelled'     => Havato_I18N::t( 'status_cancelled' ),
			'pending_admin' => Havato_I18N::t( 'status_pending_admin' ),
		);

		echo '<div class="hv-adm-filterbar">';
		foreach ( $filters as $key => $label ) {
			printf(
				'<a class="hv-adm-chip%s" href="%s">%s</a>',
				$key === $status ? ' is-active' : '',
				esc_url( add_query_arg( array( 'page' => 'havato-events', 'status' => $key ), admin_url( 'admin.php' ) ) ),
				esc_html( $label )
			);
		}
		echo '</div>';

		if ( empty( $rows ) ) {
			echo '<div class="hv-adm-card"><p class="hv-adm-muted">' .
				esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p></div>';
			self::foot();
			return;
		}

		// Fetch every guest for the events on THIS page in one query. Doing it
		// per-event would mean 20 extra round-trips (N+1) and would make the
		// screen crawl once the platform has real traffic.
		$ids          = wp_list_pluck( $rows, 'id' );
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%s' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$members = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT event_id, user_id, status, checked_in, amount
				 FROM $regs
				 WHERE event_id IN ($placeholders) AND status <> 'cancelled'
				 ORDER BY id ASC",
				$ids
			),
			ARRAY_A
		);

		$by_event = array();
		foreach ( (array) $members as $m ) {
			$by_event[ $m['event_id'] ][] = $m;
		}

		foreach ( $rows as $row ) {
			self::render_event_card( $row, isset( $by_event[ $row['id'] ] ) ? $by_event[ $row['id'] ] : array(), $lang );
		}

		self::pagination( $total, $per_page, $paged, array( 'page' => 'havato-events', 'status' => $status ) );
		self::foot();
	}

	/**
	 * One event plus its guest list.
	 *
	 * @param array  $row     Event row.
	 * @param array  $members Registrations.
	 * @param string $lang    Language.
	 */
	private static function render_event_card( $row, $members, $lang ) {
		$badges = array(
			'open'          => 'is-green',
			'matched'       => 'is-blue',
			'completed'     => 'is-gray',
			'pending_admin' => 'is-yellow',
		);
		$class = isset( $badges[ $row['status'] ] ) ? $badges[ $row['status'] ] : 'is-gray';
		$title = trim( (string) $row['title'] );
		$city  = havato_city_label( (string) $row['venue_city'] );

		echo '<div class="hv-adm-card hv-adm-event">';

		echo '<div class="hv-adm-event-head">';
		echo '<div class="hv-adm-event-title">';
		if ( ! empty( $row['image'] ) ) {
			printf(
				'<img class="hv-adm-event-img" src="%s" alt="" loading="lazy">',
				esc_url( $row['image'] )
			);
		}
		echo '<div>';
		echo '<h2 class="hv-adm-card-title">' .
			esc_html( '' !== $title ? $title : Havato_I18N::t( 'explore_title' ) ) . '</h2>';
		echo '<p class="hv-adm-muted">' .
			esc_html( $row['venue_name'] ) .
			( $city[ $lang ] ? ' · ' . esc_html( $city[ $lang ] ) : '' ) .
			' · ' . esc_html( Havato_Jalali::format( $row['event_date'], $lang ) ) .
			' — ' . esc_html( substr( $row['event_time'], 0, 5 ) ) .
			'</p>';
		echo '</div></div>';
		echo '<div class="hv-adm-event-meta">';
		echo '<span class="hv-adm-badge ' . esc_attr( $class ) . '">' .
			esc_html( Havato_I18N::t( 'status_' . $row['status'] ) ) . '</span>';
		echo '<span class="hv-adm-badge is-blue">' .
			esc_html( $row['taken'] . ' / ' . $row['max_capacity'] ) . '</span>';

		// Show the physical layout so the admin knows this is 3x4, not one 12.
		$layout = array();
		foreach ( Havato_REST::event_tables( $row['id'] ) as $tbl ) {
			$layout[] = $tbl['table_number']
				? sprintf( '#%d (%d)', $tbl['table_number'], $tbl['seats'] )
				: $tbl['quantity'] . '×' . $tbl['seats'];
		}
		if ( ! empty( $layout ) ) {
			echo '<span class="hv-adm-badge is-gray">' . esc_html( implode( ' + ', $layout ) ) . '</span>';
		}
		if ( ! empty( $row['theme'] ) ) {
			echo '<span class="hv-adm-badge is-yellow">' . esc_html( $row['theme'] ) . '</span>';
		}
		echo '</div></div>';

		self::event_actions( $row, $members );

		if ( empty( $members ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p></div>';
			return;
		}

		echo '<div class="hv-adm-guests">';
		foreach ( $members as $m ) {
			$uid     = (int) $m['user_id'];
			$profile = havato_get_profile( $uid );

			echo '<div class="hv-adm-guest">';
			printf(
				'<img class="hv-adm-guest-avatar" src="%s" alt="" loading="lazy">',
				esc_url( havato_avatar( $uid ) )
			);
			echo '<div class="hv-adm-guest-info">';
			echo '<strong>' . esc_html( havato_display_name( $uid ) ) . '</strong>';
			echo '<span class="hv-adm-muted">★ ' . esc_html( round( havato_effective_rating( $profile ), 1 ) );
			if ( (int) $profile['age'] ) {
				echo ' · ' . esc_html( $profile['age'] );
			}
			echo '</span>';
			echo '</div>';

			echo '<div class="hv-adm-guest-tags">';
			if ( (int) $m['checked_in'] ) {
				echo '<span class="hv-adm-badge is-green">✓</span>';
			}
			echo '</div>';
			echo '</div>';
		}
		echo '</div></div>';
	}

	/**
	 * One event: full details, and the edit form when asked for.
	 *
	 * @param string $event_id Event id.
	 * @param bool   $editing  Render the edit form.
	 */
	private static function page_event_single( $event_id, $editing ) {
		global $wpdb;

		$lang   = Havato_I18N::current_lang();
		$events = Havato_DB::table( 'events' );
		$venues = Havato_DB::table( 'venues' );
		$regs   = Havato_DB::table( 'event_registrations' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT e.*, v.name AS venue_name, v.city AS venue_city, v.address AS venue_address,
						v.manager_phone AS venue_phone,
						(SELECT COALESCE(SUM(r.seats),0) FROM $regs r WHERE r.event_id = e.id
						 AND r.status <> 'cancelled') AS taken
				 FROM $events e
				 LEFT JOIN $venues v ON v.id = e.venue_id
				 WHERE e.id = %s",
				$event_id
			),
			ARRAY_A
		);

		self::head( Havato_I18N::t( 'admin_events' ), Havato_I18N::t( 'event_details' ) );

		printf(
			'<p><a class="hv-adm-btn hv-adm-btn-ghost" href="%s">&larr; %s</a></p>',
			esc_url( add_query_arg( array( 'page' => 'havato-events' ), admin_url( 'admin.php' ) ) ),
			esc_html( Havato_I18N::t( 'admin_events' ) )
		);

		if ( ! $row ) {
			echo '<div class="hv-adm-card"><p class="hv-adm-muted">' .
				esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p></div>';
			self::foot();
			return;
		}

		if ( $editing ) {
			self::render_event_edit_form( $row );
		}

		// ---- details ----
		$city = havato_city_label( (string) $row['venue_city'] );

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' .
			esc_html( '' !== trim( (string) $row['title'] ) ? $row['title'] : Havato_I18N::t( 'explore_title' ) ) .
			'</h2>';

		echo '<table class="hv-adm-table"><tbody>';
		$rows = array(
			'venue_name'    => $row['venue_name'],
			'q_city_select' => isset( $city[ $lang ] ) ? $city[ $lang ] : '',
			'venue_address' => $row['venue_address'],
			'col_date'      => Havato_Jalali::format( $row['event_date'], $lang ),
			'event_time'    => substr( (string) $row['event_time'], 0, 5 ),
			'event_theme'   => $row['theme'],
			'col_status'    => Havato_I18N::t( 'status_' . $row['status'] ),
			// taken / capacity — labelled as occupancy, not as "seats left",
			// which would have read as the exact opposite of the figure.
			'seats_occupancy' => $row['taken'] . ' / ' . $row['max_capacity'],
			// Café contact stays admin-only, exactly as on every other screen.
			'venue_phone'   => $row['venue_phone'],
		);
		foreach ( $rows as $key => $value ) {
			if ( '' === (string) $value ) {
				continue;
			}
			printf(
				'<tr><td><strong>%s</strong></td><td>%s</td></tr>',
				esc_html( Havato_I18N::t( $key ) ),
				esc_html( (string) $value )
			);
		}
		echo '</tbody></table>';

		// Physical layout, so the admin can see this is 3x4 and not one 12.
		$layout = array();
		foreach ( Havato_REST::event_tables( $row['id'] ) as $tbl ) {
			$layout[] = $tbl['table_number']
				? sprintf( '#%d (%d)', $tbl['table_number'], $tbl['seats'] )
				: $tbl['quantity'] . '×' . $tbl['seats'];
		}
		if ( ! empty( $layout ) ) {
			echo '<p><strong>' . esc_html( Havato_I18N::t( 'tab_tables' ) ) . ':</strong> ' .
				esc_html( implode( ' + ', $layout ) ) . '</p>';
		}
		echo '</div>';

		// ---- guests ----
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$members = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT user_id, status, checked_in, seats FROM $regs
				 WHERE event_id = %s AND status <> 'cancelled' ORDER BY id ASC",
				$event_id
			),
			ARRAY_A
		);

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'members_at_table' ) ) . '</h2>';

		if ( empty( $members ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p>';
		} else {
			echo '<table class="hv-adm-table"><thead><tr>';
			echo '<th>' . esc_html( Havato_I18N::t( 'col_manager' ) ) . '</th>';
			echo '<th>' . esc_html( Havato_I18N::t( 'seats_reserved' ) ) . '</th>';
			echo '<th>' . esc_html( Havato_I18N::t( 'col_status' ) ) . '</th>';
			echo '</tr></thead><tbody>';

			foreach ( $members as $m ) {
				$uid     = (int) $m['user_id'];
				$profile = havato_get_profile( $uid );

				echo '<tr><td>' . esc_html( havato_display_name( $uid ) ) .
					' <span class="hv-adm-muted">★ ' .
					esc_html( round( havato_effective_rating( $profile ), 1 ) ) . '</span><br>' .
					self::ban_button( $uid ) . '</td>';
				echo '<td>' . esc_html( (int) $m['seats'] ) . '</td>';
				echo '<td>' . ( (int) $m['checked_in']
					? '<span class="hv-adm-badge is-green">✓</span>'
					: '<span class="hv-adm-badge is-gray">—</span>' ) . '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		self::foot();
	}

	/**
	 * Edit form for one event.
	 *
	 * Capacity is deliberately absent: it is derived from the physical tables
	 * the café selected, so typing a number here would let the matcher seat
	 * more people than there are chairs. Tables are edited in the café panel.
	 *
	 * @param array $row Event row.
	 */
	private static function render_event_edit_form( $row ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="hv-adm-card">';
		self::form_fields( 'event_save' );
		printf( '<input type="hidden" name="event_id" value="%s">', esc_attr( $row['id'] ) );

		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'event_edit' ) ) . '</h2>';

		echo '<div class="hv-adm-fields">';
		printf(
			'<label>%s<input type="text" name="title" value="%s" maxlength="191"></label>',
			esc_html( Havato_I18N::t( 'event_title' ) ),
			esc_attr( $row['title'] )
		);
		printf(
			'<label>%s<input type="text" name="theme" value="%s" maxlength="191"></label>',
			esc_html( Havato_I18N::t( 'event_theme' ) ),
			esc_attr( $row['theme'] )
		);
		printf(
			'<label>%s<textarea name="description" rows="3" maxlength="1000">%s</textarea></label>',
			esc_html( Havato_I18N::t( 'event_about' ) ),
			esc_textarea( isset( $row['description'] ) ? (string) $row['description'] : '' )
		);
		// Gregorian in the admin form: a date input speaks ISO, and the list
		// screen already renders the Jalali equivalent.
		printf(
			'<label>%s<input type="date" name="event_date" value="%s" required></label>',
			esc_html( Havato_I18N::t( 'col_date' ) ),
			esc_attr( $row['event_date'] )
		);
		printf(
			'<label>%s<input type="time" name="event_time" value="%s" required></label>',
			esc_html( Havato_I18N::t( 'event_time' ) ),
			esc_attr( substr( (string) $row['event_time'], 0, 5 ) )
		);

		echo '<label>' . esc_html( Havato_I18N::t( 'col_status' ) ) . '<select name="status">';
		foreach ( array( 'open', 'matched', 'completed', 'cancelled', 'pending_admin' ) as $state ) {
			printf(
				'<option value="%s"%s>%s</option>',
				esc_attr( $state ),
				selected( $state, $row['status'], false ),
				esc_html( Havato_I18N::t( 'status_' . $state ) )
			);
		}
		echo '</select></label>';
		echo '</div>';

		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-blue">' .
			esc_html( Havato_I18N::t( 'save' ) ) . '</button>';
		echo '</form>';
	}

	/**
	 * Edit / cancel / details controls under an event card.
	 *
	 * @param array $row     Event row.
	 * @param array $members Registrations.
	 */
	private static function event_actions( $row, $members ) {
		$event_id = (string) $row['id'];
		$booked   = count( (array) $members );

		echo '<div class="hv-adm-actions hv-adm-event-actions">';

		printf(
			'<a class="hv-adm-btn hv-adm-btn-ghost" href="%s">%s</a>',
			esc_url( add_query_arg( array( 'page' => 'havato-events', 'event' => $event_id ), admin_url( 'admin.php' ) ) ),
			esc_html( Havato_I18N::t( 'event_details' ) )
		);

		printf(
			'<a class="hv-adm-btn hv-adm-btn-ghost" href="%s">%s</a>',
			esc_url( add_query_arg( array( 'page' => 'havato-events', 'event' => $event_id, 'edit' => 1 ), admin_url( 'admin.php' ) ) ),
			esc_html( Havato_I18N::t( 'event_edit' ) )
		);

		// Cancelling keeps the row and its guest list — it is a status change,
		// not a delete, so nobody's history disappears and the guests can
		// still be told what happened.
		if ( 'cancelled' !== $row['status'] ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">';
			self::form_fields( 'event_cancel' );
			printf( '<input type="hidden" name="event_id" value="%s">', esc_attr( $event_id ) );
			printf(
				'<button type="submit" class="hv-adm-btn hv-adm-btn-danger" onclick="return confirm(%s)">%s</button>',
				esc_attr( wp_json_encode( $booked
					? sprintf( Havato_I18N::t( 'event_cancel_confirm_guests' ), $booked )
					: Havato_I18N::t( 'event_cancel_confirm' ) ) ),
				esc_html( Havato_I18N::t( 'event_cancel' ) )
			);
			echo '</form>';
		} else {
			echo '<span class="hv-adm-badge is-gray">' . esc_html( Havato_I18N::t( 'status_cancelled' ) ) . '</span>';
		}

		echo '</div>';
	}

	/**
	 * Simple pager shared by the new listing screens.
	 *
	 * @param int   $total    Total rows.
	 * @param int   $per_page Rows per page.
	 * @param int   $paged    Current page.
	 * @param array $args     Base query args.
	 */
	private static function pagination( $total, $per_page, $paged, $args ) {
		$pages = (int) ceil( $total / max( 1, $per_page ) );
		if ( $pages < 2 ) {
			return;
		}

		echo '<div class="hv-adm-pager">';
		for ( $i = 1; $i <= $pages; $i++ ) {
			printf(
				'<a class="hv-adm-chip%s" href="%s">%s</a>',
				$i === $paged ? ' is-active' : '',
				esc_url( add_query_arg( array_merge( $args, array( 'paged' => $i ) ), admin_url( 'admin.php' ) ) ),
				esc_html( $i )
			);
		}
		echo '</div>';
	}

	/* =====================================================================
	 * Page — every café
	 * ================================================================== */

	/**
	 * Full café directory with search, city / status filters and paging.
	 *
	 * The approvals screen only surfaces what needs action; this is the
	 * complete list for day-to-day lookup.
	 */
	public static function page_venues() {
		global $wpdb;
		Havato_DB::ensure_tables();

		$lang   = Havato_I18N::current_lang();
		$venues = Havato_DB::table( 'venues' );
		$events = Havato_DB::table( 'events' );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$city = isset( $_GET['city'] ) ? sanitize_key( wp_unslash( $_GET['city'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$state = isset( $_GET['state'] ) ? sanitize_key( wp_unslash( $_GET['state'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$paged = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;

		$per_page = 20;
		$offset   = ( $paged - 1 ) * $per_page;

		$where = '1=1';
		if ( '' !== $search ) {
			$like   = '%' . $wpdb->esc_like( $search ) . '%';
			$where .= $wpdb->prepare( ' AND (v.name LIKE %s OR v.manager_name LIKE %s OR v.address LIKE %s)', $like, $like, $like );
		}
		if ( $city ) {
			$where .= $wpdb->prepare( ' AND v.city = %s', $city );
		}
		if ( 'verified' === $state ) {
			$where .= ' AND v.verified = 1';
		} elseif ( 'pending' === $state ) {
			$where .= ' AND v.verified = 0';
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $venues v WHERE $where" );

		// One query with the event count folded in, rather than a lookup per row.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT v.*,
						(SELECT COUNT(*) FROM $events e WHERE e.venue_id = v.id) AS event_count
				 FROM $venues v
				 WHERE $where
				 ORDER BY v.verified ASC, v.created_at DESC
				 LIMIT %d OFFSET %d",
				$per_page,
				$offset
			),
			ARRAY_A
		);

		self::head( Havato_I18N::t( 'admin_venues' ), Havato_I18N::t( 'stat_venues' ) );

		// Search + filters.
		echo '<form method="get" class="hv-adm-card hv-adm-inline-form">';
		echo '<input type="hidden" name="page" value="havato-venues">';
		printf(
			'<label class="hv-adm-grow">%s<input type="search" name="s" value="%s" placeholder="%s"></label>',
			esc_html( Havato_I18N::t( 'search' ) ),
			esc_attr( $search ),
			esc_attr( Havato_I18N::t( 'venue_name' ) . ' / ' . Havato_I18N::t( 'col_manager' ) )
		);

		echo '<label>' . esc_html( Havato_I18N::t( 'q_city_select' ) ) . '<select name="city">';
		printf( '<option value="">%s</option>', esc_html( Havato_I18N::t( 'filter' ) ) );
		foreach ( havato_locations() as $country ) {
			foreach ( $country['cities'] as $code => $label ) {
				printf(
					'<option value="%s"%s>%s</option>',
					esc_attr( $code ),
					selected( $code, $city, false ),
					esc_html( $label[ $lang ] )
				);
			}
		}
		echo '</select></label>';

		echo '<label>' . esc_html( Havato_I18N::t( 'col_status' ) ) . '<select name="state">';
		foreach ( array(
			''         => Havato_I18N::t( 'filter' ),
			'verified' => Havato_I18N::t( 'verified_venue' ),
			'pending'  => Havato_I18N::t( 'badge_pending' ),
		) as $key => $label ) {
			printf( '<option value="%s"%s>%s</option>', esc_attr( $key ), selected( $key, $state, false ), esc_html( $label ) );
		}
		echo '</select></label>';

		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-blue">' .
			esc_html( Havato_I18N::t( 'search' ) ) . '</button>';
		echo '</form>';

		if ( empty( $rows ) ) {
			echo '<div class="hv-adm-card"><p class="hv-adm-muted">' .
				esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p></div>';
			self::foot();
			return;
		}

		echo '<div class="hv-adm-card">';
		printf(
			'<h2 class="hv-adm-card-title">%s (%s)</h2>',
			esc_html( Havato_I18N::t( 'stat_venues' ) ),
			esc_html( $total )
		);

		echo '<table class="hv-adm-table"><thead><tr>';
		echo '<th>' . esc_html( Havato_I18N::t( 'venue_name' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_manager' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'q_city_select' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'tab_venue_events' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'guests_routed' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_status' ) ) . '</th>';
		echo '<th></th></tr></thead><tbody>';

		foreach ( $rows as $row ) {
			$account    = get_user_by( 'id', (int) $row['manager_id'] );
			$city_label = havato_city_label( (string) $row['city'] );
			$shot       = $row['storefront_photo'] ? $row['storefront_photo'] : $row['image'];

			echo '<tr>';

			echo '<td><div class="hv-adm-venue-cell">';
			if ( $shot ) {
				printf(
					'<a href="%1$s" target="_blank" rel="noopener"><img class="hv-adm-shopfront" src="%1$s" alt="" loading="lazy"></a>',
					esc_url( $shot )
				);
			} else {
				echo '<span class="hv-adm-shopfront is-empty"><span class="dashicons dashicons-store"></span></span>';
			}
			echo '<div><strong>' . esc_html( $row['name'] ) . '</strong><br>' .
				'<span class="hv-adm-muted">' . esc_html( wp_trim_words( (string) $row['address'], 6, '…' ) ) . '</span></div>';
			echo '</div></td>';

			// The café's contact number is administrator-only: it is shown
			// here and in approvals, and never travels to a guest.
			$phone = isset( $row['manager_phone'] ) ? (string) $row['manager_phone'] : '';
			echo '<td>' . esc_html( $row['manager_name'] ? $row['manager_name'] : '—' ) . '<br>' .
				'<span class="hv-adm-muted">' . esc_html( $account ? $account->user_email : '—' ) . '</span>' .
				( '' !== $phone
					? '<br><span class="hv-adm-muted" dir="ltr">' . esc_html( $phone ) . '</span>'
					: '' ) .
				'</td>';
			echo '<td>' . esc_html( $city_label[ $lang ] ) . '</td>';
			echo '<td>' . esc_html( $row['event_count'] ) . '</td>';
			echo '<td>' . esc_html( $row['guests_routed'] ) . '</td>';
			echo '<td>' . ( (int) $row['verified']
				? '<span class="hv-adm-badge is-green">✓ ' . esc_html( Havato_I18N::t( 'verified_venue' ) ) . '</span>'
				: '<span class="hv-adm-badge is-yellow">' . esc_html( Havato_I18N::t( 'badge_pending' ) ) . '</span>' ) . '</td>';

			echo '<td class="hv-adm-actions">';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			self::form_fields( 'verify' );
			echo '<input type="hidden" name="venue_id" value="' . esc_attr( $row['id'] ) . '">';
			echo '<input type="hidden" name="verified" value="' . ( (int) $row['verified'] ? '0' : '1' ) . '">';
			printf(
				'<button type="submit" class="hv-adm-btn %s">%s</button>',
				(int) $row['verified'] ? 'hv-adm-btn-ghost' : 'hv-adm-btn-green',
				esc_html( (int) $row['verified'] ? Havato_I18N::t( 'cancel' ) : Havato_I18N::t( 'verify_action' ) )
			);
			echo '</form>';
			echo '</td></tr>';
		}

		echo '</tbody></table></div>';

		self::pagination(
			$total,
			$per_page,
			$paged,
			array( 'page' => 'havato-venues', 's' => $search, 'city' => $city, 'state' => $state )
		);
		self::foot();
	}

	/* =====================================================================
	 * Page — bulk import cafés from JSON
	 * ================================================================== */

	/**
	 * Paste a JSON array of cafés and create them in one go.
	 *
	 * Venues are created WITHOUT a WordPress account (manager_id = 0), because
	 * seeding a directory should not mean inventing twenty fake logins. An
	 * owner can be attached later by registering with that café's name.
	 */
	public static function page_import() {
		Havato_DB::ensure_tables();

		self::head( Havato_I18N::t( 'admin_import' ), Havato_I18N::t( 'stat_venues' ) );

		$sample = "[\n  {\n    \"name\": \"کافه طهرون\",\n    \"city\": \"تهران\",\n"
			. "    \"latitude\": 35.70057,\n    \"longitude\": 51.41239\n  }\n]";

		echo '<div class="hv-adm-alert is-blue">' . esc_html( Havato_I18N::t( 'import_hint' ) ) . '</div>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="hv-adm-card">';
		self::form_fields( 'import_venues' );

		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'admin_import' ) ) . '</h2>';

		printf(
			'<textarea name="payload" rows="14" class="hv-adm-json" placeholder="%s" required></textarea>',
			esc_attr( $sample )
		);

		echo '<label class="hv-adm-switch"><input type="checkbox" name="verified" value="1" checked><span></span>' .
			esc_html( Havato_I18N::t( 'import_verified' ) ) . '</label>';

		echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'import_cities' ) ) . ' ';
		$names = array();
		foreach ( havato_locations() as $country ) {
			foreach ( $country['cities'] as $label ) {
				$names[] = $label['fa'] . ' / ' . $label['en'];
			}
		}
		echo esc_html( implode( '، ', $names ) ) . '</p>';

		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-green">' .
			esc_html( Havato_I18N::t( 'import_run' ) ) . '</button>';
		echo '</form>';

		self::foot();
	}

	/**
	 * Resolve a human city name ("تهران", "Tehran") to its internal key.
	 *
	 * @param string $name City as written by a human.
	 * @return string Key, or '' when we do not operate there.
	 */
	private static function resolve_city( $name ) {
		$name = trim( (string) $name );
		if ( '' === $name ) {
			return '';
		}

		foreach ( havato_locations() as $country ) {
			foreach ( $country['cities'] as $key => $label ) {
				if ( 0 === strcasecmp( $name, $key )
					|| $name === $label['fa']
					|| 0 === strcasecmp( $name, $label['en'] ) ) {
					return $key;
				}
			}
		}

		return '';
	}

	/**
	 * Country that owns a city key.
	 *
	 * @param string $city City key.
	 * @return string
	 */
	private static function country_of_city( $city ) {
		foreach ( havato_locations() as $code => $country ) {
			if ( isset( $country['cities'][ $city ] ) ) {
				return $code;
			}
		}
		return 'ir';
	}

	/**
	 * Create venues from a decoded JSON array.
	 *
	 * @param array $items    Rows.
	 * @param bool  $verified Publish immediately.
	 * @return array {created, skipped, errors}
	 */
	public static function import_venues( $items, $verified ) {
		global $wpdb;

		$venues  = Havato_DB::table( 'venues' );
		$created = 0;
		$skipped = 0;
		$errors  = array();

		foreach ( (array) $items as $i => $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$name = isset( $item['name'] ) ? sanitize_text_field( $item['name'] ) : '';
			$city = self::resolve_city( isset( $item['city'] ) ? $item['city'] : '' );
			$lat  = isset( $item['latitude'] ) ? (float) $item['latitude'] : 0;
			$lng  = isset( $item['longitude'] ) ? (float) $item['longitude'] : 0;

			if ( '' === $name ) {
				$errors[] = sprintf( '#%d: %s', $i + 1, Havato_I18N::t( 'venue_name' ) );
				continue;
			}
			if ( '' === $city ) {
				$errors[] = sprintf(
					'#%d %s: %s',
					$i + 1,
					$name,
					isset( $item['city'] ) ? sanitize_text_field( $item['city'] ) : '—'
				);
				continue;
			}

			// Skip a café we already have in that city, so re-running the
			// import does not create duplicates.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$exists = $wpdb->get_var(
				$wpdb->prepare( "SELECT id FROM $venues WHERE name = %s AND city = %s LIMIT 1", $name, $city )
			);
			if ( $exists ) {
				$skipped++;
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->insert(
				$venues,
				array(
					'id'           => havato_uid( 'v' ),
					'name'         => $name,
					'manager_name' => isset( $item['manager'] ) ? sanitize_text_field( $item['manager'] ) : '',
					'country'      => self::country_of_city( $city ),
					'city'         => $city,
					'address'      => isset( $item['address'] ) ? sanitize_textarea_field( $item['address'] ) : '',
					'lat'          => $lat,
					'lng'          => $lng,
					'image'        => isset( $item['image'] ) ? esc_url_raw( $item['image'] ) : '',
					'budget_tier'  => 'medium',
					'verified'     => $verified ? 1 : 0,
					'manager_id'   => 0,
					'menu_json'    => '[]',
					// Imported venues are real data: never flagged as demo, so
					// "delete demo content" can never remove them.
					'is_demo'      => 0,
					'created_at'   => havato_now(),
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%f', '%s', '%s', '%d', '%d', '%s', '%d', '%s' )
			);

			$created++;
		}

		Havato_Logger::log(
			sprintf( 'Bulk import: %d café(s) created, %d skipped.', $created, $skipped ),
			'success'
		);

		return array(
			'created' => $created,
			'skipped' => $skipped,
			'errors'  => $errors,
		);
	}

	/**
	 * Onboard a café.
	 *
	 * Public owner signup was removed with the mobile portal, so the platform
	 * admin creates the account here; the owner then manages everything from
	 * their own wp-admin panel.
	 */
	private static function render_new_venue_form() {
		$lang      = Havato_I18N::current_lang();
		$locations = havato_locations();

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="hv-adm-card">';
		self::form_fields( 'new_venue' );
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'owner_signup' ) ) . '</h2>';

		echo '<div class="hv-adm-fields">';
		printf(
			'<label>%s<input type="text" name="venue_name" required></label>',
			esc_html( Havato_I18N::t( 'venue_name' ) )
		);
		printf(
			'<label>%s<input type="text" name="manager_name" required></label>',
			esc_html( Havato_I18N::t( 'manager_name' ) )
		);
		printf(
			'<label>%s<input type="email" name="email" required></label>',
			esc_html( Havato_I18N::t( 'email' ) )
		);
		printf(
			'<label>%s<input type="text" name="password" required minlength="6"></label>',
			esc_html( Havato_I18N::t( 'password' ) )
		);

		echo '<label>' . esc_html( Havato_I18N::t( 'q_country' ) ) . '<select name="country">';
		foreach ( $locations as $code => $info ) {
			printf( '<option value="%s">%s</option>', esc_attr( $code ), esc_html( $info['label'][ $lang ] ) );
		}
		echo '</select></label>';

		echo '<label>' . esc_html( Havato_I18N::t( 'q_city_select' ) ) . '<select name="city">';
		foreach ( $locations as $info ) {
			foreach ( $info['cities'] as $code => $label ) {
				printf(
					'<option value="%s">%s — %s</option>',
					esc_attr( $code ),
					esc_html( $label[ $lang ] ),
					esc_html( $info['label'][ $lang ] )
				);
			}
		}
		echo '</select></label>';

		printf(
			'<label>%s<input type="text" name="address"></label>',
			esc_html( Havato_I18N::t( 'venue_address' ) )
		);
		echo '</div>';

		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-green">' .
			esc_html( Havato_I18N::t( 'owner_signup' ) ) . '</button>';
		echo '</form>';
	}

	/**
	 * The venue verification table.
	 *
	 * @param int $limit Rows.
	 */
	private static function render_pending_table( $limit = 20 ) {
		global $wpdb;
		$venues = Havato_DB::table( 'venues' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $venues ORDER BY verified ASC, created_at DESC LIMIT %d", (int) $limit ), ARRAY_A );

		if ( empty( $rows ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p>';
			return;
		}

		echo '<table class="hv-adm-table"><thead><tr>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_order' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'venue_name' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_manager' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'q_city_select' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_location' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_status' ) ) . '</th>';
		echo '<th></th></tr></thead><tbody>';

		$i = 1;
		foreach ( $rows as $row ) {
			$account = get_user_by( 'id', (int) $row['manager_id'] );
			$name    = $row['name'];
			$manager = '' !== $row['manager_name']
				? $row['manager_name']
				: ( $account ? havato_display_name( (int) $row['manager_id'] ) : '—' );

			echo '<tr>';
			echo '<td><span class="hv-adm-order">' . esc_html( $i ) . '</span></td>';
			// Show the storefront photo inline: it is the evidence the admin
			// needs in order to approve, so it must not hide behind a click.
			$shot = isset( $row['storefront_photo'] ) ? $row['storefront_photo'] : '';
			echo '<td><div class="hv-adm-venue-cell">';
			if ( $shot ) {
				printf(
					'<a href="%1$s" target="_blank" rel="noopener"><img class="hv-adm-shopfront" src="%1$s" alt=""></a>',
					esc_url( $shot )
				);
			} else {
				echo '<span class="hv-adm-shopfront is-empty"><span class="dashicons dashicons-camera"></span></span>';
			}
			echo '<strong>' . esc_html( $name ) . '</strong>';
			echo '</div></td>';
			$mphone = isset( $row['manager_phone'] ) ? (string) $row['manager_phone'] : '';
			echo '<td>' . esc_html( $manager ) . '<br><span class="hv-adm-muted">' .
				esc_html( $account ? $account->user_email : '—' ) . '</span>' .
				( '' !== $mphone ? '<br><span class="hv-adm-muted" dir="ltr">' . esc_html( $mphone ) . '</span>' : '' ) .
				'</td>';
			$city_label = havato_city_label( isset( $row['city'] ) ? $row['city'] : '' );
			echo '<td>' . esc_html( $city_label[ Havato_I18N::current_lang() ] ) . '</td>';
			echo '<td>' . esc_html( wp_trim_words( (string) $row['address'], 8, '…' ) ) . '</td>';
			echo '<td>' . ( $row['verified']
				? '<span class="hv-adm-badge is-green">✓ ' . esc_html( Havato_I18N::t( 'verified_venue' ) ) . '</span>'
				: '<span class="hv-adm-badge is-yellow">' . esc_html( Havato_I18N::t( 'badge_pending' ) ) . '</span>' ) . '</td>';
			echo '<td class="hv-adm-actions">';

			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			self::form_fields( 'verify' );
			echo '<input type="hidden" name="venue_id" value="' . esc_attr( $row['id'] ) . '">';
			echo '<input type="hidden" name="verified" value="' . ( $row['verified'] ? '0' : '1' ) . '">';
			printf(
				'<button type="submit" class="hv-adm-btn %s">%s</button>',
				$row['verified'] ? 'hv-adm-btn-ghost' : 'hv-adm-btn-green',
				esc_html( $row['verified'] ? Havato_I18N::t( 'cancel' ) : Havato_I18N::t( 'verify_action' ) )
			);
			echo '</form>';

			echo '</td></tr>';
			$i++;
		}

		echo '</tbody></table>';
	}

	/**
	 * Pending menu approvals.
	 */
	private static function render_menu_queue() {
		global $wpdb;
		$venues = Havato_DB::table( 'venues' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( "SELECT * FROM $venues WHERE pending_menu_json <> '' AND pending_menu_json IS NOT NULL", ARRAY_A );

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'menu_pending_badge' ) ) . '</h2>';

		if ( empty( $rows ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p>';
			echo '</div>';
			return;
		}

		foreach ( $rows as $row ) {
			$items = havato_json( $row['pending_menu_json'] );
			$name  = $row['name'];

			echo '<div class="hv-adm-subcard">';
			echo '<div class="hv-adm-row-between"><strong>' . esc_html( $name ) . '</strong>';
			echo '<span class="hv-adm-badge is-yellow">' . esc_html( count( $items ) ) . '</span></div>';

			// Restaurant-style rows: photo | name + description | price.
			echo '<ul class="hv-adm-menu-list">';
			foreach ( $items as $item ) {
				$img   = isset( $item['image'] ) ? trim( (string) $item['image'] ) : '';
				$desc  = isset( $item['desc'] ) ? trim( (string) $item['desc'] ) : '';
				$price = isset( $item['price'] ) ? (int) $item['price'] : 0;

				echo '<li class="hv-adm-menu-row">';

				if ( $img ) {
					printf(
						'<img class="hv-adm-menu-thumb" src="%s" alt="%s" loading="lazy">',
						esc_url( $img ),
						esc_attr( $item['name'] )
					);
				} else {
					echo '<span class="hv-adm-menu-thumb is-empty"><span class="dashicons dashicons-food"></span></span>';
				}

				echo '<span class="hv-adm-menu-info">';
				echo '<strong>' . esc_html( $item['name'] ) . '</strong>';
				if ( '' !== $desc ) {
					echo '<span class="hv-adm-muted">' . esc_html( $desc ) . '</span>';
				}
				echo '</span>';

				// Priced in the café's own currency, not the reviewer's.
				echo '<b class="hv-adm-menu-price">' .
					esc_html( havato_price( $price, null, isset( $row['country'] ) ? $row['country'] : '' ) ) .
					'</b>';
				echo '</li>';
			}
			echo '</ul>';

			echo '<div class="hv-adm-actions">';
			// NOTE: PHP casts numeric string array keys to integers, so a
			// `'1' => …` key arrives here as int(1). Comparing it with the
			// string '1' via === is always false, which previously labelled the
			// green approve button "reject". Use an explicit list instead.
			$menu_actions = array(
				array(
					'approve' => 1,
					'class'   => 'hv-adm-btn-green',
					'label'   => Havato_I18N::t( 'verify_action' ),
				),
				array(
					'approve' => 0,
					'class'   => 'hv-adm-btn-ghost',
					'label'   => Havato_I18N::t( 'reject' ),
				),
			);

			foreach ( $menu_actions as $menu_action ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
				self::form_fields( 'menu' );
				echo '<input type="hidden" name="venue_id" value="' . esc_attr( $row['id'] ) . '">';
				echo '<input type="hidden" name="approve" value="' . esc_attr( $menu_action['approve'] ) . '">';
				printf(
					'<button type="submit" class="hv-adm-btn %s">%s</button>',
					esc_attr( $menu_action['class'] ),
					esc_html( $menu_action['label'] )
				);
				echo '</form>';
			}
			echo '</div></div>';
		}

		echo '</div>';
	}

	/**
	 * Reported photos queue.
	 */
	private static function render_photo_reports() {
		global $wpdb;
		$reports = Havato_DB::table( 'photo_reports' );
		$photos  = Havato_DB::table( 'user_photos' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			"SELECT r.*, p.photo_url, p.user_id
			 FROM $reports r LEFT JOIN $photos p ON p.id = r.photo_id
			 WHERE r.status = 'pending' ORDER BY r.id DESC LIMIT 30",
			ARRAY_A
		);

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'report' ) ) . '</h2>';

		if ( empty( $rows ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p>';
			echo '</div>';
			return;
		}

		echo '<div class="hv-adm-report-grid">';
		foreach ( $rows as $row ) {
			echo '<div class="hv-adm-report">';
			if ( $row['photo_url'] ) {
				echo '<img src="' . esc_url( $row['photo_url'] ) . '" alt="">';
			}
			echo '<div class="hv-adm-report-meta">';
			echo '<span class="hv-adm-badge is-yellow">' . esc_html( $row['reason'] ) . '</span>';
			echo '<span class="hv-adm-muted">' . esc_html( havato_display_name( (int) $row['user_id'] ) ) . '</span>';
			echo '</div>';

			echo '<div class="hv-adm-actions">';
			foreach ( array( 'remove' => 'hv-adm-btn-danger', 'keep' => 'hv-adm-btn-ghost' ) as $act => $class ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
				self::form_fields( 'photo' );
				echo '<input type="hidden" name="report_id" value="' . esc_attr( $row['id'] ) . '">';
				echo '<input type="hidden" name="action_type" value="' . esc_attr( $act ) . '">';
				printf(
					'<button type="submit" class="hv-adm-btn %s">%s</button>',
					esc_attr( $class ),
					esc_html( 'remove' === $act ? Havato_I18N::t( 'delete' ) : Havato_I18N::t( 'confirm' ) )
				);
				echo '</form>';
			}
			echo '</div></div>';
		}
		echo '</div></div>';
	}

	/* =====================================================================
	 * Page 3 — run the matcher
	 * ================================================================== */

	/**
	 * Matcher page.
	 */
	public static function page_matcher() {
		global $wpdb;
		Havato_DB::ensure_tables();

		$events = Havato_DB::table( 'events' );
		$venues = Havato_DB::table( 'venues' );
		$regs   = Havato_DB::table( 'event_registrations' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			"SELECT e.*, v.name AS venue_name,
					(SELECT COALESCE(SUM(r.seats),0) FROM $regs r WHERE r.event_id = e.id AND r.status <> 'cancelled') AS taken
			 FROM $events e LEFT JOIN $venues v ON v.id = e.venue_id
			 ORDER BY e.event_date ASC LIMIT 40",
			ARRAY_A
		);

		$lang = Havato_I18N::current_lang();

		self::head( Havato_I18N::t( 'admin_matcher' ), Havato_I18N::t( 'live_console' ) );

		echo '<div class="hv-adm-grid">';

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'explore_title' ) ) . '</h2>';
		echo '<p class="hv-adm-muted">' .
			esc_html__( 'The engine runs automatically when the last seat is taken, and a cron job forces it a few hours before each event. This button is only a manual backup.', 'havato' ) .
			'</p>';

		if ( empty( $rows ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p>';
		} else {
			echo '<table class="hv-adm-table"><thead><tr>';
			echo '<th>' . esc_html( Havato_I18N::t( 'col_order' ) ) . '</th>';
			echo '<th>' . esc_html( Havato_I18N::t( 'venue_name' ) ) . '</th>';
			echo '<th>' . esc_html( Havato_I18N::t( 'col_date' ) ) . '</th>';
			echo '<th>' . esc_html( Havato_I18N::t( 'col_status' ) ) . '</th>';
			echo '<th></th></tr></thead><tbody>';

			$i = 1;
			foreach ( $rows as $row ) {
				$name = $row['venue_name'];

				echo '<tr>';
				echo '<td><span class="hv-adm-order">' . esc_html( $i ) . '</span></td>';
				echo '<td><strong>' . esc_html( $name ) . '</strong><br><span class="hv-adm-muted">' .
					esc_html( $row['taken'] . ' / ' . $row['max_capacity'] ) . '</span></td>';
				echo '<td>' . esc_html( Havato_Jalali::format( $row['event_date'], $lang ) . ' — ' . substr( $row['event_time'], 0, 5 ) ) . '</td>';
				echo '<td><span class="hv-adm-badge is-' . ( 'open' === $row['status'] ? 'yellow' : 'green' ) . '">' .
					esc_html( Havato_I18N::t( 'status_' . $row['status'] ) ) . '</span></td>';
				echo '<td class="hv-adm-actions">';
				if ( 'open' === $row['status'] ) {
					printf(
						'<button type="button" class="hv-adm-btn hv-adm-btn-blue" data-run-matcher="%s">%s</button>',
						esc_attr( $row['id'] ),
						esc_html( Havato_I18N::t( 'admin_matcher' ) )
					);
				} else {
					echo '<span class="hv-adm-muted">—</span>';
				}
				echo '</td></tr>';
				$i++;
			}

			echo '</tbody></table>';
		}

		echo '<p><button type="button" class="hv-adm-btn hv-adm-btn-green" data-run-matcher="all">▶ ' .
			esc_html( Havato_I18N::t( 'admin_matcher' ) ) . '</button></p>';
		echo '</div>';

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'live_console' ) ) . '</h2>';
		self::console( 22 );
		echo '</div>';

		echo '</div>';
		self::foot();
	}

	/* =====================================================================
	 * Page 4 — formula weights
	 * ================================================================== */

	/**
	 * Weights page.
	 */
	public static function page_weights() {
		$s = Havato_Settings::all();

		self::head( Havato_I18N::t( 'admin_weights' ), Havato_I18N::t( 'live_console' ) );

		echo '<div class="hv-adm-grid">';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="hv-adm-card">';
		self::form_fields( 'weights' );
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'admin_weights' ) ) . '</h2>';

		self::slider( 'w_location', Havato_I18N::t( 'weight_location' ), $s['w_location'], 0, 100, '%' );
		self::slider( 'w_time', Havato_I18N::t( 'weight_time' ), $s['w_time'], 0, 100, '%' );
		self::slider( 'w_density', Havato_I18N::t( 'weight_density' ), $s['w_density'], 0, 100, '%' );
		self::slider( 'w_shared_interest', 'Shared interest bonus', $s['w_shared_interest'], 0, 40 );
		self::slider( 'w_speaker_listener', 'Speaker × listener bonus', $s['w_speaker_listener'], 0, 40 );
		self::slider( 'w_intro_extro', 'Introvert × extrovert bonus', $s['w_intro_extro'], 0, 40 );
		self::slider( 'w_ambivert', 'Two ambiverts bonus', $s['w_ambivert'], 0, 40 );
		self::slider( 'w_same_vibe', 'Same vibe bonus', $s['w_same_vibe'], 0, 40 );
		self::slider( 'w_age_penalty', 'Age gap penalty (per year)', $s['w_age_penalty'], 0, 12 );
		self::slider( 'w_age_threshold', 'Free age gap (years)', $s['w_age_threshold'], 0, 20 );
		self::slider( 'w_rating', 'Behaviour score weight', $s['w_rating'], 0, 30 );
		self::slider( 'w_trait_humor', 'Similar sense of humour', $s['w_trait_humor'], 0, 30 );
		self::slider( 'w_trait_energy', 'Similar preferred atmosphere', $s['w_trait_energy'], 0, 30 );
		self::slider( 'w_trait_empathy', 'A good listener at the table', $s['w_trait_empathy'], 0, 30 );
		self::slider( 'penalty_no_show', 'Penalty for not turning up', $s['penalty_no_show'], 0, 5 );
		self::slider( 'penalty_empty_seat', 'Penalty per empty reserved seat', $s['penalty_empty_seat'], 0, 5 );
		self::slider( 'penalty_floor', 'Behaviour score never drops below', $s['penalty_floor'], 0, 5 );
		self::slider( 'w_gender_balance', 'Gender balance weight', $s['w_gender_balance'], 0, 60 );

		echo '<label class="hv-adm-switch"><input type="checkbox" name="gender_balance_on" value="1" ' .
			checked( 1, (int) $s['gender_balance_on'], false ) . '><span></span>' .
			esc_html__( 'Take table gender balance into account', 'havato' ) . '</label>';

		echo '<div class="hv-adm-fields">';
		printf(
			'<label>%s<input type="number" name="cron_lead_hours" value="%d" min="1" max="72"></label>',
			esc_html__( 'Force matching N hours before the event', 'havato' ),
			(int) $s['cron_lead_hours']
		);
		printf(
			'<label>%s<input type="number" name="auto_complete_hours" value="%d" min="1" max="24"></label>',
			esc_html__( 'Mark the event completed N hours after start', 'havato' ),
			(int) $s['auto_complete_hours']
		);
		echo '</div>';

		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-blue">' . esc_html( Havato_I18N::t( 'save' ) ) . '</button>';
		echo '</form>';

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'live_console' ) ) . '</h2>';
		self::console( 16 );
		echo '</div>';

		echo '</div>';
		self::foot();
	}

	/* =====================================================================
	 * Page 5 — Google sign-in
	 * ================================================================== */

	/**
	 * Google settings page.
	 */
	public static function page_google() {
		$s = Havato_Settings::all();

		self::head( Havato_I18N::t( 'admin_google' ), Havato_I18N::t( 'login_google' ) );

		echo '<div class="hv-adm-grid">';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="hv-adm-card">';
		self::form_fields( 'google' );
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'admin_google' ) ) . '</h2>';

		echo '<div class="hv-adm-fields">';
		printf(
			'<label>Client ID<input type="text" name="google_client_id" value="%s" placeholder="xxxxx.apps.googleusercontent.com"></label>',
			esc_attr( $s['google_client_id'] )
		);
		printf(
			'<label>Client secret<input type="password" name="google_client_secret" value="%s" autocomplete="new-password"></label>',
			esc_attr( $s['google_client_secret'] )
		);
		echo '</div>';

		echo '<div class="hv-adm-note">';
		echo '<p><strong>' . esc_html__( 'Authorized JavaScript origin', 'havato' ) . ':</strong> <code>' . esc_html( home_url() ) . '</code></p>';
		echo '<p><strong>' . esc_html__( 'Authorized redirect URI', 'havato' ) . ':</strong> <code>' . esc_html( home_url( '/' ) ) . '</code></p>';
		echo '<p class="hv-adm-muted">' . esc_html__( 'Create the credentials in Google Cloud Console → APIs & Services → Credentials → OAuth client ID (Web application).', 'havato' ) . '</p>';
		echo '</div>';

		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-blue">' . esc_html( Havato_I18N::t( 'save' ) ) . '</button>';
		echo '</form>';

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'col_status' ) ) . '</h2>';
		echo Havato_Google_Auth::is_configured()
			? '<p><span class="hv-adm-badge is-green">✓ ' . esc_html( Havato_I18N::t( 'confirm' ) ) . '</span></p>'
			: '<p><span class="hv-adm-badge is-yellow">' . esc_html( Havato_I18N::t( 'google_not_configured' ) ) . '</span></p>';
		self::console( 10 );
		echo '</div>';

		echo '</div>';
		self::foot();
	}

	/* =====================================================================
	 * Page — chats & reports (administrator only)
	 * ================================================================== */

	/**
	 * Reported messages, plus a searchable archive of every conversation.
	 *
	 * Guests are told in the app that chats are stored and may be reviewed if
	 * reported, so this screen is not a surprise to them.
	 */
	public static function page_chats() {
		global $wpdb;
		Havato_DB::ensure_tables();

		self::head( Havato_I18N::t( 'admin_chats' ), Havato_I18N::t( 'chat_reports' ) );

		self::render_flagged_summary();
		self::render_chat_reports();
		self::render_blocklists();
		self::render_chat_archive();

		self::foot();
	}

	/**
	 * Every block a guest currently holds, with a way to lift it.
	 *
	 * Until 1.23.0 a block could be placed from a table chat. That is no
	 * longer offered, but the entries it created are still on file — and a
	 * blocklist entry is a hard constraint in the matcher, so it permanently
	 * narrows who that guest can be seated with. This screen exists so those
	 * old, one-tap blocks can be reviewed and lifted.
	 */
	private static function render_blocklists() {
		global $wpdb;

		$profiles = Havato_DB::table( 'user_profiles' );

		// Only rows that actually hold a list; an empty array still encodes
		// as "[]", so the length test is what keeps the query honest.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			"SELECT user_id, blocklist_json FROM $profiles
			 WHERE blocklist_json IS NOT NULL
			   AND blocklist_json <> ''
			   AND CHAR_LENGTH(blocklist_json) > 2
			 ORDER BY user_id ASC
			 LIMIT 200",
			ARRAY_A
		);

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'blocklists_title' ) ) . '</h2>';
		echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'blocklists_hint' ) ) . '</p>';

		$pairs = array();
		foreach ( (array) $rows as $row ) {
			$owner = (int) $row['user_id'];
			foreach ( havato_json( $row['blocklist_json'] ) as $target ) {
				$target = (int) $target;
				if ( $target > 0 ) {
					$pairs[] = array( $owner, $target );
				}
			}
		}

		if ( empty( $pairs ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p></div>';
			return;
		}

		echo '<table class="hv-adm-table"><thead><tr>';
		echo '<th>' . esc_html( Havato_I18N::t( 'blocklist_owner' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'blocklist_target' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'blocklist_effect' ) ) . '</th>';
		echo '<th></th>';
		echo '</tr></thead><tbody>';

		foreach ( $pairs as $pair ) {
			list( $owner, $target ) = $pair;

			// A block is one-directional in storage but the matcher treats it
			// symmetrically, so say so rather than letting the admin guess.
			$mutual = havato_is_blocked( $target, $owner );

			echo '<tr>';
			echo '<td>' . esc_html( havato_display_name( $owner ) ) .
				' <span class="hv-adm-muted">#' . esc_html( $owner ) . '</span></td>';
			echo '<td>' . esc_html( havato_display_name( $target ) ) .
				' <span class="hv-adm-muted">#' . esc_html( $target ) . '</span></td>';
			echo '<td><span class="hv-adm-badge is-yellow">' .
				esc_html( Havato_I18N::t( 'blocklist_never_seated' ) ) . '</span>';
			if ( $mutual ) {
				echo ' <span class="hv-adm-badge is-gray">' .
					esc_html( Havato_I18N::t( 'blocklist_mutual' ) ) . '</span>';
			}
			echo '</td>';

			echo '<td>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">';
			self::form_fields( 'clear_block' );
			echo '<input type="hidden" name="owner_id" value="' . esc_attr( $owner ) . '">';
			echo '<input type="hidden" name="target_id" value="' . esc_attr( $target ) . '">';
			printf(
				'<button type="submit" class="hv-adm-btn hv-adm-btn-ghost" onclick="return confirm(%s)">%s</button>',
				esc_attr( wp_json_encode( Havato_I18N::t( 'blocklist_clear_confirm' ) ) ),
				esc_html( Havato_I18N::t( 'blocklist_clear' ) )
			);
			echo '</form>';
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
		echo '</div>';
	}

	/**
	 * Headline count of messages the word filter marked.
	 *
	 * Shown first so the administrator can see at a glance that something is
	 * waiting, without scrolling the archive.
	 */
	private static function render_flagged_summary() {
		global $wpdb;

		$chats = Havato_DB::table( 'chats' );
		$pm    = Havato_DB::table( 'private_chats' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$group_flagged = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $chats WHERE flagged = 1" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$private_flagged = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $pm WHERE flagged = 1" );

		if ( 0 === $group_flagged && 0 === $private_flagged ) {
			return;
		}

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">⚑ ' . esc_html( Havato_I18N::t( 'needs_review' ) ) . '</h2>';
		echo '<p class="hv-adm-note">';
		printf(
			'<a href="%s"><strong>%s</strong> %s — %s</a> · ',
			esc_url( admin_url( 'admin.php?page=havato-chats&scope=group&flagged=1' ) ),
			esc_html( number_format_i18n( $group_flagged ) ),
			esc_html( Havato_I18N::t( 'flagged_count' ) ),
			esc_html( Havato_I18N::t( 'chat_group_col' ) )
		);
		printf(
			'<a href="%s"><strong>%s</strong> %s — %s</a>',
			esc_url( admin_url( 'admin.php?page=havato-chats&scope=private&flagged=1' ) ),
			esc_html( number_format_i18n( $private_flagged ) ),
			esc_html( Havato_I18N::t( 'flagged_count' ) ),
			esc_html( Havato_I18N::t( 'chat_private_col' ) )
		);
		echo '</p></div>';
	}

	/**
	 * The moderation queue.
	 */
	private static function render_chat_reports() {
		global $wpdb;

		$reports = Havato_DB::table( 'message_reports' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results( "SELECT * FROM $reports WHERE status = 'pending' ORDER BY id DESC LIMIT 100", ARRAY_A );

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'chat_reports' ) ) . '</h2>';

		if ( empty( $rows ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'no_reports' ) ) . '</p></div>';
			return;
		}

		echo '<table class="hv-adm-table"><thead><tr>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_order' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'report_reason' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_message' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_manager' ) ) . '</th>';
		echo '<th></th></tr></thead><tbody>';

		$i = 1;
		foreach ( $rows as $row ) {
			echo '<tr>';
			echo '<td><span class="hv-adm-order">' . esc_html( $i ) . '</span></td>';
			echo '<td><span class="hv-adm-badge is-yellow">' .
				esc_html( Havato_I18N::t( 'reason_' . $row['reason'] ) ) . '</span><br>' .
				'<span class="hv-adm-muted">' . esc_html( 'private' === $row['scope']
					? Havato_I18N::t( 'chat_private_col' )
					: Havato_I18N::t( 'chat_group_col' ) ) . '</span></td>';
			echo '<td style="max-width:380px">' . esc_html( wp_trim_words( (string) $row['excerpt'], 30, '…' ) ) . '</td>';
			echo '<td>' . esc_html( havato_display_name( (int) $row['reported_id'] ) ) . '<br>' .
				'<span class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'report' ) ) . ': ' .
				esc_html( havato_display_name( (int) $row['reporter_id'] ) ) . '</span></td>';

			echo '<td class="hv-adm-actions">';
			foreach ( array( 'keep' => 'keep_message', 'delete' => 'remove_message' ) as $action => $label ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">';
				self::form_fields( 'chat_report' );
				echo '<input type="hidden" name="report_id" value="' . esc_attr( $row['id'] ) . '">';
				echo '<input type="hidden" name="action_type" value="' . esc_attr( $action ) . '">';
				printf(
					'<button type="submit" class="hv-adm-btn %s">%s</button>',
					'delete' === $action ? 'hv-adm-btn-danger' : 'hv-adm-btn-ghost',
					esc_html( Havato_I18N::t( $label ) )
				);
				echo '</form> ';
			}
			echo '</td></tr>';
			$i++;
		}

		echo '</tbody></table></div>';
	}

	/**
	 * Ban / unban control for one user.
	 *
	 * A ban is a user-meta flag rather than a deletion, so the person's
	 * history stays intact and the decision can be undone.
	 *
	 * @param int $user_id Target.
	 * @return string HTML.
	 */
	private static function ban_button( $user_id ) {
		$user_id = (int) $user_id;

		// Never offer to ban another administrator from here.
		if ( user_can( $user_id, 'manage_options' ) ) {
			return '<span class="hv-adm-muted">—</span>';
		}

		$banned = havato_is_banned( $user_id );

		ob_start();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">';
		self::form_fields( 'ban_user' );
		echo '<input type="hidden" name="user_id" value="' . esc_attr( $user_id ) . '">';
		echo '<input type="hidden" name="banned" value="' . ( $banned ? '0' : '1' ) . '">';
		printf(
			'<button type="submit" class="hv-adm-btn %s">%s</button>',
			$banned ? 'hv-adm-btn-ghost' : 'hv-adm-btn-danger',
			esc_html( $banned ? Havato_I18N::t( 'unban_user' ) : Havato_I18N::t( 'ban_user' ) )
		);
		echo '</form>';
		return ob_get_clean();
	}

	/**
	 * Searchable archive of stored conversations.
	 */
	private static function render_chat_archive() {
		global $wpdb;

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$scope = isset( $_GET['scope'] ) ? sanitize_key( wp_unslash( $_GET['scope'] ) ) : 'group';
		$scope = 'private' === $scope ? 'private' : 'group';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$only_flagged = isset( $_GET['flagged'] ) && '1' === $_GET['flagged'];
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$paged = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;

		$per_page = 50;
		$offset   = ( $paged - 1 ) * $per_page;

		$table = 'private' === $scope
			? Havato_DB::table( 'private_chats' )
			: Havato_DB::table( 'chats' );

		$where = '1=1';
		if ( '' !== $search ) {
			$like   = '%' . $wpdb->esc_like( $search ) . '%';
			$where .= $wpdb->prepare( ' AND message_text LIKE %s', $like );
		}
		if ( $only_flagged ) {
			$where .= ' AND flagged = 1';
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE $where" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM $table WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ),
			ARRAY_A
		);

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'chat_log' ) ) . '</h2>';

		echo '<form method="get" class="hv-adm-filterbar">';
		echo '<input type="hidden" name="page" value="havato-chats">';
		printf(
			'<input type="search" name="s" value="%s" placeholder="%s">',
			esc_attr( $search ),
			esc_attr( Havato_I18N::t( 'search' ) )
		);
		echo '<select name="scope">';
		printf(
			'<option value="group"%s>%s</option>',
			selected( 'group', $scope, false ),
			esc_html( Havato_I18N::t( 'chat_group_col' ) )
		);
		printf(
			'<option value="private"%s>%s</option>',
			selected( 'private', $scope, false ),
			esc_html( Havato_I18N::t( 'chat_private_col' ) )
		);
		echo '</select>';
		printf(
			'<label class="hv-adm-switch"><input type="checkbox" name="flagged" value="1"%s><span></span>%s</label>',
			checked( true, $only_flagged, false ),
			esc_html( Havato_I18N::t( 'only_flagged' ) )
		);
		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-blue">' . esc_html( Havato_I18N::t( 'search' ) ) . '</button>';
		echo '</form>';

		if ( empty( $rows ) ) {
			echo '<p class="hv-adm-muted">' . esc_html( Havato_I18N::t( 'empty_state' ) ) . '</p></div>';
			return;
		}

		echo '<table class="hv-adm-table"><thead><tr>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_date' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_manager' ) ) . '</th>';
		echo '<th>' . esc_html( Havato_I18N::t( 'col_message' ) ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rows as $row ) {
			$sender  = (int) $row['sender_id'];
			$flagged = ! empty( $row['flagged'] );

			echo '<tr' . ( $flagged ? ' class="hv-adm-flagged"' : '' ) . '>';
			echo '<td><span class="hv-adm-muted" dir="ltr">' . esc_html( substr( (string) $row['message_time'], 0, 16 ) ) . '</span></td>';

			echo '<td>' . esc_html( $sender ? havato_display_name( $sender ) : Havato_I18N::t( 'system_message' ) );
			if ( $sender ) {
				echo '<br>' . self::ban_button( $sender );
			}
			echo '</td>';

			echo '<td>';
			if ( $flagged ) {
				echo '<span class="hv-adm-badge is-yellow" title="' .
					esc_attr( (string) $row['flag_term'] ) . '">⚑ ' .
					esc_html( Havato_I18N::t( 'needs_review' ) ) . '</span> ';
			}
			// A system line is stored as a per-language JSON object; print the
			// admin's own language rather than the raw payload.
			echo esc_html( havato_message_text( $row['message_text'], empty( $row['sender_id'] ) ) ) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
		self::pagination( $total, $per_page, $paged, array( 'page' => 'havato-chats', 's' => $search, 'scope' => $scope ) );
		echo '</div>';
	}

	/* =====================================================================
	 * Page — appearance & theme
	 * ================================================================== */

	/**
	 * Theme picker.
	 *
	 * Each card is its own form so choosing a theme is a single click; the
	 * palette is previewed with the real gradients rather than flat chips, so
	 * what the administrator sees is what the app will look like.
	 */
	public static function page_theme() {
		$active  = Havato_Themes::current_id();
		$themes  = Havato_Themes::catalogue();
		$lang    = Havato_I18N::current_lang();
		$post_to = admin_url( 'admin-post.php' );

		self::head( Havato_I18N::t( 'admin_theme' ), Havato_I18N::t( 'theme_active' ) );

		echo '<div class="hv-adm-card">';
		echo '<p class="hv-adm-note">' . esc_html( Havato_I18N::t( 'theme_intro' ) ) . '</p>';
		echo '</div>';

		echo '<div class="hv-theme-grid">';

		foreach ( $themes as $id => $theme ) {
			$t        = Havato_Themes::normalize( $theme );
			$is_live  = ( $id === $active );
			$label    = isset( $t['label'][ $lang ] ) ? $t['label'][ $lang ] : $id;
			$note     = isset( $t['note'][ $lang ] ) ? $t['note'][ $lang ] : '';
			$ratio    = Havato_Themes::contrast( '#ffffff', $t['base'] );

			printf(
				'<form method="post" action="%s" class="hv-theme-card%s">',
				esc_url( $post_to ),
				$is_live ? ' is-active' : ''
			);
			self::form_fields( 'theme' );
			echo '<input type="hidden" name="theme_id" value="' . esc_attr( $id ) . '">';

			// Miniature of the real screen.
			printf(
				'<div class="hv-theme-preview" style="background:%s">',
				esc_attr( $t['canvas'] )
			);
			printf(
				'<div class="hv-theme-hdr" style="background:linear-gradient(135deg,%s 0%%,%s 48%%,%s 100%%)"></div>',
				esc_attr( $t['light'] ),
				esc_attr( $t['base'] ),
				esc_attr( $t['deep'] )
			);
			printf(
				'<div class="hv-theme-row" style="background:linear-gradient(135deg,%s,%s 58%%,%s)"></div>',
				esc_attr( $t['light'] ),
				esc_attr( $t['base'] ),
				esc_attr( $t['deep'] )
			);
			echo '<div class="hv-theme-cards"><span></span><span></span><span></span></div>';
			printf(
				'<div class="hv-theme-cta" style="background:linear-gradient(120deg,%s,%s)"></div>',
				esc_attr( $t['light'] ),
				esc_attr( $t['base'] )
			);
			printf(
				'<div class="hv-theme-nav" style="background:linear-gradient(135deg,%s,%s)">'
					. '<i style="background:linear-gradient(140deg,%s,%s)"></i></div>',
				esc_attr( $t['base'] ),
				esc_attr( $t['deep'] ),
				esc_attr( Havato_Themes::lighten( $t['accent'], 0.2 ) ),
				esc_attr( $t['accent'] )
			);
			echo '</div>';

			echo '<div class="hv-theme-meta">';
			echo '<h3>' . esc_html( $label );
			if ( $is_live ) {
				echo ' <span class="hv-adm-badge is-green">' . esc_html( Havato_I18N::t( 'theme_in_use' ) ) . '</span>';
			}
			echo '</h3>';

			if ( $note ) {
				echo '<p>' . esc_html( $note ) . '</p>';
			}

			echo '<div class="hv-theme-swatches">';
			foreach ( Havato_Themes::swatches( $t ) as $hex ) {
				printf( '<span style="background:%s" title="%s"></span>', esc_attr( $hex ), esc_attr( $hex ) );
			}
			echo '</div>';

			printf(
				'<p class="hv-theme-ratio">%s: <strong>%s:1</strong> — %s</p>',
				esc_html( Havato_I18N::t( 'theme_contrast' ) ),
				esc_html( number_format( $ratio, 2 ) ),
				esc_html( Havato_I18N::t( 'theme_contrast_ok' ) )
			);

			printf(
				'<button type="submit" class="hv-adm-btn %s"%s>%s</button>',
				$is_live ? 'hv-adm-btn-ghost' : 'hv-adm-btn-blue',
				$is_live ? ' disabled' : '',
				esc_html( $is_live ? Havato_I18N::t( 'theme_in_use' ) : Havato_I18N::t( 'theme_apply' ) )
			);

			echo '</div></form>';
		}

		echo '</div>';

		// ---- custom palette ----
		$custom = get_option( Havato_Themes::CUSTOM_OPTION, array() );
		$custom = Havato_Themes::normalize( is_array( $custom ) ? $custom : array() );

		echo '<form method="post" action="' . esc_url( $post_to ) . '" class="hv-adm-card">';
		self::form_fields( 'theme' );
		echo '<input type="hidden" name="theme_id" value="custom">';
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'theme_custom' ) );
		if ( 'custom' === $active ) {
			echo ' <span class="hv-adm-badge is-green">' . esc_html( Havato_I18N::t( 'theme_in_use' ) ) . '</span>';
		}
		echo '</h2>';
		echo '<p class="hv-adm-note">' . esc_html( Havato_I18N::t( 'theme_custom_hint' ) ) . '</p>';

		echo '<div class="hv-adm-fields">';
		printf(
			'<label>%s<input type="color" name="custom_base" value="%s"></label>',
			esc_html( Havato_I18N::t( 'theme_base_colour' ) ),
			esc_attr( $custom['base'] )
		);
		printf(
			'<label>%s<input type="color" name="custom_accent" value="%s"></label>',
			esc_html( Havato_I18N::t( 'theme_accent_colour' ) ),
			esc_attr( $custom['accent'] )
		);
		echo '</div>';

		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-blue">' .
			esc_html( Havato_I18N::t( 'theme_apply' ) ) . '</button>';
		echo '</form>';

		echo '<div class="hv-adm-card"><p class="hv-adm-note">' .
			esc_html( Havato_I18N::t( 'theme_developer_note' ) ) .
			' <code>add_filter( \'havato_themes\', … )</code></p></div>';

		self::foot();
	}

	/* =====================================================================
	 * Page 6 — language & region
	 * ================================================================== */

	/**
	 * Locale page.
	 */
	public static function page_locale() {
		$s = Havato_Settings::all();

		self::head( Havato_I18N::t( 'admin_locale' ), Havato_I18N::t( 'lang_label' ) );

		echo '<div class="hv-adm-grid">';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="hv-adm-card">';
		self::form_fields( 'locale' );
		echo '<h2 class="hv-adm-card-title">' . esc_html( Havato_I18N::t( 'admin_locale' ) ) . '</h2>';

		echo '<div class="hv-adm-fields">';
		echo '<label>' . esc_html( Havato_I18N::t( 'lang_label' ) ) . '<select name="default_lang">';
		foreach ( Havato_I18N::languages() as $code => $info ) {
			printf(
				'<option value="%s"%s>%s (%s)</option>',
				esc_attr( $code ),
				selected( $code, $s['default_lang'], false ),
				esc_html( $info['label'] ),
				esc_html( strtoupper( $info['dir'] ) )
			);
		}
		echo '</select></label>';

		printf(
			'<label>%s<input type="number" step="0.0001" name="map_center_lat" value="%s"></label>',
			esc_html__( 'Map center latitude', 'havato' ),
			esc_attr( $s['map_center_lat'] )
		);
		printf(
			'<label>%s<input type="number" step="0.0001" name="map_center_lng" value="%s"></label>',
			esc_html__( 'Map center longitude', 'havato' ),
			esc_attr( $s['map_center_lng'] )
		);
		printf(
			'<label>%s<input type="number" name="map_zoom" value="%d" min="3" max="18"></label>',
			esc_html__( 'Default map zoom', 'havato' ),
			(int) $s['map_zoom']
		);
		echo '</div>';

		echo '<label class="hv-adm-switch"><input type="checkbox" name="allow_lang_switch" value="1" ' .
			checked( 1, (int) $s['allow_lang_switch'], false ) . '><span></span>' .
			esc_html__( 'Show the in-app language switcher', 'havato' ) . '</label>';

		echo '<label class="hv-adm-switch"><input type="checkbox" name="photo_auto_approve" value="1" ' .
			checked( 1, (int) $s['photo_auto_approve'], false ) . '><span></span>' .
			esc_html__( 'Auto-approve gallery photos', 'havato' ) . '</label>';

		echo '<label class="hv-adm-switch"><input type="checkbox" name="owner_login_guard" value="1" ' .
			checked( 1, (int) $s['owner_login_guard'], false ) . '><span></span>' .
			esc_html__( 'Send café owners from wp-login.php to the branded café page', 'havato' ) . '</label>';
		echo '<p class="hv-adm-muted">' .
			esc_html__( 'Administrators are never redirected: any sign-in aimed at wp-admin goes to WordPress as usual, and wp-login.php?havato_admin=1 always works.', 'havato' ) .
			'</p>';

		echo '<button type="submit" class="hv-adm-btn hv-adm-btn-blue">' . esc_html( Havato_I18N::t( 'save' ) ) . '</button>';
		echo '</form>';

		echo '<div class="hv-adm-card">';
		echo '<h2 class="hv-adm-card-title">' . esc_html__( 'Shortcode & app URLs', 'havato' ) . '</h2>';
		echo '<div class="hv-adm-note">';
		echo '<p><code>[havato_app]</code> — ' . esc_html__( 'place it on any page.', 'havato' ) . '</p>';
		echo '<p><strong>WebView / APK:</strong> <code>' . esc_html( Havato_PWA::app_url() ) . '</code></p>';
		echo '<p><strong>Manifest:</strong> <code>' . esc_html( Havato_PWA::url( 'manifest' ) ) . '</code></p>';
		echo '<p><strong>Service worker:</strong> <code>' . esc_html( Havato_PWA::url( 'sw' ) ) . '</code></p>';
		echo '</div>';
		self::console( 10 );
		echo '</div>';

		echo '</div>';
		self::foot();
	}

	/* =====================================================================
	 * POST handler
	 * ================================================================== */

	/**
	 * Handle every admin form submission.
	 */
	public static function handle_post() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		check_admin_referer( 'havato_admin', 'havato_nonce' );

		global $wpdb;

		$action  = isset( $_POST['havato_action'] ) ? sanitize_key( wp_unslash( $_POST['havato_action'] ) ) : '';
		$message = Havato_I18N::t( 'saved' );
		$page    = 'havato';
		$extra   = array();

		switch ( $action ) {
			case 'import_venues':
				// Raw JSON: only unslash, never sanitise the whole blob or the
				// quotes would be mangled before json_decode() sees them.
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				$raw   = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '';
				$items = json_decode( (string) $raw, true );

				if ( ! is_array( $items ) ) {
					$message = Havato_I18N::t( 'import_bad_json' );
					$page    = 'havato-import';
					break;
				}

				$result = self::import_venues( $items, ! empty( $_POST['verified'] ) );

				$message = sprintf(
					Havato_I18N::t( 'import_done' ),
					$result['created'],
					$result['skipped']
				);
				if ( ! empty( $result['errors'] ) ) {
					$message .= ' — ' . Havato_I18N::t( 'import_failed_rows' ) . ': ' .
						implode( ' | ', array_slice( $result['errors'], 0, 5 ) );
				}
				$page = 'havato-venues';
				break;

			case 'new_venue':
				$req = new WP_REST_Request( 'POST' );
				foreach ( array( 'venue_name', 'manager_name', 'email', 'country', 'city' ) as $key ) {
					$req->set_param( $key, isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '' );
				}
				$req->set_param( 'address', isset( $_POST['address'] ) ? sanitize_textarea_field( wp_unslash( $_POST['address'] ) ) : '' );
				// Not sanitised: a password must survive verbatim.
				$req->set_param( 'password', isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : '' );

				// owner_register() logs the new user in, which would kick the
				// administrator out of their own session — capture and restore.
				$admin_id = get_current_user_id();
				$result   = Havato_REST::owner_register( $req );
				wp_set_current_user( $admin_id );
				wp_set_auth_cookie( $admin_id, true );

				$message = is_wp_error( $result ) ? $result->get_error_message() : Havato_I18N::t( 'saved' );
				$page    = 'havato-approvals';
				break;

			case 'verify':
				$venue_id = isset( $_POST['venue_id'] ) ? sanitize_text_field( wp_unslash( $_POST['venue_id'] ) ) : '';
				$verified = isset( $_POST['verified'] ) ? (int) $_POST['verified'] : 1;

				global $wpdb;
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->update( Havato_DB::table( 'venues' ), array( 'verified' => $verified ), array( 'id' => $venue_id ), array( '%d' ), array( '%s' ) );
				Havato_REST::sync_venue_events( $venue_id, (bool) $verified );
				Havato_Logger::log( sprintf( 'Venue %s %s by administrator.', $venue_id, $verified ? 'verified' : 'suspended' ), 'success' );
				// Return to whichever screen the button was clicked on, so
				// verifying from the café directory does not bounce the admin
				// over to the approvals queue.
				$from = isset( $_POST['return_page'] ) ? sanitize_key( wp_unslash( $_POST['return_page'] ) ) : '';
				$page = in_array( $from, array( 'havato-venues', 'havato-approvals' ), true ) ? $from : 'havato-approvals';
				break;

			case 'menu':
				$venue_id = isset( $_POST['venue_id'] ) ? sanitize_text_field( wp_unslash( $_POST['venue_id'] ) ) : '';
				$approve  = ! empty( $_POST['approve'] );

				$request = new WP_REST_Request( 'POST' );
				$request->set_param( 'venue_id', $venue_id );
				$request->set_param( 'approve', $approve );
				Havato_REST::admin_menu_approve( $request );
				$page = 'havato-approvals';
				break;

			case 'photo':
				$request = new WP_REST_Request( 'POST' );
				$request->set_param( 'report_id', isset( $_POST['report_id'] ) ? (int) $_POST['report_id'] : 0 );
				$request->set_param( 'action_type', isset( $_POST['action_type'] ) ? sanitize_key( wp_unslash( $_POST['action_type'] ) ) : 'keep' );
				Havato_REST::admin_photo_report( $request );
				$page = 'havato-approvals';
				break;

			case 'weights':
				$keys = array(
					'w_location', 'w_time', 'w_density', 'w_shared_interest', 'w_speaker_listener',
					'w_intro_extro', 'w_ambivert', 'w_same_vibe', 'w_age_penalty', 'w_age_threshold',
					'w_rating', 'w_gender_balance', 'cron_lead_hours', 'auto_complete_hours',
					'w_trait_humor', 'w_trait_energy', 'w_trait_empathy',
					'penalty_no_show', 'penalty_empty_seat', 'penalty_floor',
				);
				$values = array();
				foreach ( $keys as $key ) {
					if ( isset( $_POST[ $key ] ) ) {
						$values[ $key ] = (int) $_POST[ $key ];
					}
				}
				$values['gender_balance_on'] = empty( $_POST['gender_balance_on'] ) ? 0 : 1;
				Havato_Settings::update( $values );
				Havato_Logger::log( 'Matching weights updated by administrator.', 'info' );
				$page = 'havato-weights';
				break;

			case 'google':
				Havato_Settings::update(
					array(
						'google_client_id'     => isset( $_POST['google_client_id'] ) ? sanitize_text_field( wp_unslash( $_POST['google_client_id'] ) ) : '',
						'google_client_secret' => isset( $_POST['google_client_secret'] ) ? sanitize_text_field( wp_unslash( $_POST['google_client_secret'] ) ) : '',
					)
				);
				$page = 'havato-google';
				break;

			case 'event_save':
				$event_id = isset( $_POST['event_id'] ) ? sanitize_text_field( wp_unslash( $_POST['event_id'] ) ) : '';
				$date     = isset( $_POST['event_date'] ) ? sanitize_text_field( wp_unslash( $_POST['event_date'] ) ) : '';
				$time     = isset( $_POST['event_time'] ) ? sanitize_text_field( wp_unslash( $_POST['event_time'] ) ) : '';
				$state    = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';

				// Validate before writing: a malformed date would silently
				// become 0000-00-00 and drop the event out of every listing.
				$valid_date = (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date );
				$valid_time = (bool) preg_match( '/^\d{2}:\d{2}(:\d{2})?$/', $time );

				if ( $event_id && $valid_date && $valid_time
					&& in_array( $state, array( 'open', 'matched', 'completed', 'cancelled', 'pending_admin' ), true ) ) {

					if ( 5 === strlen( $time ) ) {
						$time .= ':00';
					}

					// phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$wpdb->update(
						Havato_DB::table( 'events' ),
						array(
							'title'       => isset( $_POST['title'] ) ? havato_clamp_text( sanitize_text_field( wp_unslash( $_POST['title'] ) ), 191 ) : '',
							'theme'       => isset( $_POST['theme'] ) ? havato_clamp_text( sanitize_text_field( wp_unslash( $_POST['theme'] ) ), 191 ) : '',
							'description' => isset( $_POST['description'] ) ? havato_clamp_text( sanitize_textarea_field( wp_unslash( $_POST['description'] ) ), 1000 ) : '',
							'event_date'  => $date,
							'event_time'  => $time,
							'status'      => $state,
						),
						array( 'id' => $event_id ),
						array( '%s', '%s', '%s', '%s', '%s', '%s' ),
						array( '%s' )
					);

					Havato_Logger::log( sprintf( 'Event %s edited by administrator.', $event_id ), 'info' );
				} else {
					$message = Havato_I18N::t( 'error_generic' );
				}

				$page  = 'havato-events';
				$extra = array( 'event' => $event_id );
				break;

			case 'event_cancel':
				$event_id = isset( $_POST['event_id'] ) ? sanitize_text_field( wp_unslash( $_POST['event_id'] ) ) : '';

				if ( $event_id ) {
					// A cancellation is a status change, never a delete: the
					// guest list, the chat and the history all stay intact so
					// the people who booked can still be accounted for.
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$wpdb->update(
						Havato_DB::table( 'events' ),
						array( 'status' => 'cancelled' ),
						array( 'id' => $event_id ),
						array( '%s' ),
						array( '%s' )
					);

					// Free the seats so they stop counting against capacity.
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$wpdb->update(
						Havato_DB::table( 'event_registrations' ),
						array( 'status' => 'cancelled' ),
						array( 'event_id' => $event_id ),
						array( '%s' ),
						array( '%s' )
					);

					Havato_Logger::log( sprintf( 'Event %s cancelled by administrator.', $event_id ), 'warn' );
					$message = Havato_I18N::t( 'event_cancelled_done' );
				}

				$page = 'havato-events';
				break;

			case 'clear_block':
				$owner  = isset( $_POST['owner_id'] ) ? (int) $_POST['owner_id'] : 0;
				$target = isset( $_POST['target_id'] ) ? (int) $_POST['target_id'] : 0;

				if ( $owner > 0 && $target > 0 ) {
					$profiles = Havato_DB::table( 'user_profiles' );
					$profile  = havato_get_profile( $owner );

					// Rebuild the list without the target rather than emptying
					// it: this guest may hold other blocks that must survive.
					$list = array_values(
						array_diff(
							array_map( 'intval', (array) $profile['blocklist'] ),
							array( $target )
						)
					);

					// phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$wpdb->update(
						$profiles,
						array( 'blocklist_json' => wp_json_encode( $list ) ),
						array( 'user_id' => $owner ),
						array( '%s' ),
						array( '%d' )
					);

					Havato_Logger::log(
						sprintf( 'Administrator lifted the block by user %d on user %d.', $owner, $target ),
						'info'
					);
					$message = Havato_I18N::t( 'blocklist_cleared' );
				}

				$page = 'havato-chats';
				break;

			case 'ban_user':
				$target = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
				$ban    = ! empty( $_POST['banned'] );

				// Guard against an administrator being locked out.
				if ( $target && ! user_can( $target, 'manage_options' ) ) {
					havato_set_banned( $target, $ban );
					Havato_Logger::log(
						sprintf( 'User %d %s by administrator.', $target, $ban ? 'banned' : 'unbanned' ),
						$ban ? 'warn' : 'info'
					);
				}
				$page = isset( $_POST['return_page'] ) ? sanitize_key( wp_unslash( $_POST['return_page'] ) ) : 'havato-chats';
				break;

			case 'chat_report':
				$request = new WP_REST_Request( 'POST' );
				$request->set_param( 'report_id', isset( $_POST['report_id'] ) ? (int) $_POST['report_id'] : 0 );
				$request->set_param( 'action_type', isset( $_POST['action_type'] ) ? sanitize_key( wp_unslash( $_POST['action_type'] ) ) : 'keep' );
				Havato_REST::admin_chat_report( $request );
				$page = 'havato-chats';
				break;

			case 'theme':
				$theme_id = isset( $_POST['theme_id'] ) ? sanitize_key( wp_unslash( $_POST['theme_id'] ) ) : '';
				$custom   = array();

				if ( 'custom' === $theme_id ) {
					// Only the two colours the picker offers are read; every
					// other shade is derived, so a malformed value cannot
					// produce a broken palette.
					$custom = array(
						'base'   => isset( $_POST['custom_base'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_base'] ) ) : '',
						'accent' => isset( $_POST['custom_accent'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_accent'] ) ) : '',
					);
				}

				$applied = Havato_Themes::set( $theme_id, $custom );
				$message = Havato_I18N::t( 'theme_applied' );
				Havato_Logger::log( sprintf( 'App theme switched to "%s" by administrator.', $applied ), 'success' );
				$page = 'havato-theme';
				break;

			case 'locale':
				Havato_Settings::update(
					array(
						'default_lang'       => isset( $_POST['default_lang'] ) ? sanitize_text_field( wp_unslash( $_POST['default_lang'] ) ) : 'fa',
						'map_center_lat'     => isset( $_POST['map_center_lat'] ) ? (float) $_POST['map_center_lat'] : 35.7219,
						'map_center_lng'     => isset( $_POST['map_center_lng'] ) ? (float) $_POST['map_center_lng'] : 51.3347,
						'map_zoom'           => isset( $_POST['map_zoom'] ) ? (int) $_POST['map_zoom'] : 12,
						'allow_lang_switch'  => empty( $_POST['allow_lang_switch'] ) ? 0 : 1,
						'photo_auto_approve' => empty( $_POST['photo_auto_approve'] ) ? 0 : 1,
						'owner_login_guard'  => empty( $_POST['owner_login_guard'] ) ? 0 : 1,
					)
				);
				$page = 'havato-locale';
				break;

			case 'purge_demo':
				require_once HAVATO_PATH . 'includes/class-havato-seeder.php';
				$result  = Havato_Seeder::purge();
				$message = $result['message'];
				break;

			case 'seed':
				require_once HAVATO_PATH . 'includes/class-havato-seeder.php';
				$result  = Havato_Seeder::run();
				$message = $result['message'];
				break;
		}

		wp_safe_redirect(
			add_query_arg(
				array_merge(
					array(
						'page'       => $page,
						'havato_msg' => rawurlencode( $message ),
					),
					// Lets a handler send the admin back to the exact record
					// they were editing rather than the top of the list.
					$extra
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}
