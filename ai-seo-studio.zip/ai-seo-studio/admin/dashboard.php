<div class="wrap ai-seo-wrap" dir="ltr">
<h1>AI SEO Content Studio</h1>
<div class="ai-card"><h2>Generate Content</h2>
<textarea id="ai-prompt" rows="4" style="width:100%" placeholder="Enter prompt..."></textarea>
<select id="ai-provider"><option>OpenAI</option><option>Gemini</option><option>Claude</option><option>DeepSeek</option><option>Groq</option><option>OpenRouter</option><option>Ollama</option></select>
<button class="button button-primary" onclick="aiGenerate()">Generate</button><div id="ai-result"></div></div>
</div>
