import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/expense_model.dart';
import '../core/utils/prefs_store.dart';

final expenseListProvider =
    StateNotifierProvider<ExpenseListNotifier, List<ExpenseModel>>((ref) {
  return ExpenseListNotifier();
});

class ExpenseListNotifier extends StateNotifier<List<ExpenseModel>> {
  late final Future<void> _hydrated;

  ExpenseListNotifier() : super(const []) {
    _hydrated = _hydrate();
  }

  Future<void> ensureLoaded() => _hydrated;

  Future<void> _hydrate() async {
    state = await PrefsStore.loadExpenses();
  }

  Future<void> _persist() async {
    await PrefsStore.saveExpenses(state);
  }

  Future<void> addExpense(ExpenseModel expense) async {
    await _hydrated;
    state = [...state, expense];
    await PrefsStore.saveExpenses(state);
  }

  Future<void> updateExpense(ExpenseModel expense) async {
    await _hydrated;
    state = [
      for (final item in state)
        if (item.id == expense.id) expense else item,
    ];
    await _persist();
  }

  Future<void> deleteExpense(String id) async {
    await _hydrated;
    state = state.where((item) => item.id != id).toList();
    await _persist();
  }

  // خلاصه‌ها
  double get totalAmount => state.fold(0, (sum, e) => sum + e.amount);

  double totalByCategory(String category) {
    return state.where((e) => e.category == category).fold(0, (s, e) => s + e.amount);
  }

  Map<String, double> get categorySummary {
    final map = <String, double>{};
    for (final e in state) {
      map[e.category] = (map[e.category] ?? 0) + e.amount;
    }
    return map;
  }
}
